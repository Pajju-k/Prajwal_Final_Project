# TODO: Customer Segmentation App Updates

## Task 1: Update Generate Data Button
- [ ] Modify `generateData()` in index.html to generate random number between 1,000-10,000
- [ ] Send random number to API endpoint
- [ ] Display confirmation with total records generated

## Task 2: Update Run Analysis Button  
- [ ] Modify `runAnalysis()` to preprocess dataset and return customer count
- [ ] Display total customer count as the analysis result in the UI

## Changes Required:

### index.html:
1. `generateData()` function:
   - Generate random n_customers = Math.floor(Math.random() * (10000 - 1000 + 1)) + 1000
   - Send to API
   - Display confirmation message

2. `runAnalysis()` function:
   - Display preprocessing status
   - Show total customer count after analysis completes
