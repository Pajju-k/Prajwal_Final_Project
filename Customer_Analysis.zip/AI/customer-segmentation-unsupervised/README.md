# AI-Driven Customer Intelligence System

## Advanced Customer Segmentation Using Unsupervised Learning

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Machine Learning](https://img.shields.io/badge/ML-Unsupervised-green.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## 📋 Project Overview

This project implements a complete end-to-end customer segmentation system using unsupervised machine learning techniques. The system discovers hidden patterns, behavioral clusters, and meaningful customer groups from raw data and converts them into actionable business insights.

## 🎯 Problem Statement

A company has collected large volumes of customer data but doesn't know:
- Who their most valuable customers are
- Which customers are likely to churn
- Which group spends the most
- Which group responds better to offers

This project applies unsupervised learning to identify meaningful segments and provide business recommendations.

## 📊 Dataset

- **Size**: 6,000+ customer records
- **Features**: 20+ features including:
  - Demographics: Age, Gender, Income
  - Behavioral: Spending Score, Purchase History, Frequency
  - Transaction: Recency, Total Amount Spent, Average Purchase Amount
  - Derived: RFM Features, Customer Lifetime Value, Risk Score

## 🧮 Algorithms Used

### 1. K-Means Clustering
- Most widely used partitioning algorithm
- Efficient for large datasets
- Uses elbow method and silhouette score for optimization

### 2. Hierarchical Clustering
- Agglomerative clustering with Ward linkage
- Creates dendrogram for visual hierarchy
- No need to pre-specify number of clusters

### 3. DBSCAN
- Density-based clustering
- Identifies outliers automatically
- No assumption of spherical clusters

### 4. Gaussian Mixture Model (GMM)
- Probabilistic clustering
- Soft clustering with probability assignments
- Uses BIC for model selection

## 📈 Model Performance

| Metric | Value |
|--------|-------|
| Algorithm | K-Means |
| Number of Clusters | 5 |
| Silhouette Score | > 0.3 |
| Davies-Bouldin Index | < 1.5 |

## 🚀 How to Run

### Prerequisites
```
bash
pip install -r requirements.txt
```

### Option 1: Run Complete Pipeline
```
bash
python main.py
```

This will:
1. Generate customer data
2. Preprocess and engineer features
3. Run all clustering algorithms
4. Analyze clusters and generate insights
5. Create visualizations

### Option 2: Run Web Interface
```
bash
cd src
python api.py
```

Then open http://localhost:5000 in your browser

### Option 3: Individual Steps
```
bash
# Generate data
python -c "from src.data_generator import generate_customer_data, add_rfm_features; df = generate_customer_data(); df = add_rfm_features(df); df.to_csv('data/raw/customer_data.csv', index=False)"

# Run analysis
python main.py
```

## 📁 Project Structure

```
customer-segmentation-unsupervised/
├── data/
│   ├── raw/                 # Original dataset
│   └── processed/          # Cleaned and engineered data
├── src/
│   ├── data_generator.py   # Generate synthetic customer data
│   ├── data_preprocessing.py  # Data cleaning and feature engineering
│   ├── clustering.py       # ML clustering algorithms
│   ├── cluster_analysis.py # Business insights generation
│   ├── visualization.py    # Charts and graphs
│   └── api.py             # Flask API
├── results/               # Output visualizations
├── reports/               # Project reports
├── notebooks/             # Jupyter notebooks
├── index.html             # Frontend dashboard
├── main.py                # Main pipeline
└── README.md              # This file
```

## 🎨 Key Results

### Customer Segments Discovered

1. **Premium Loyalists** - High CLV, frequent buyers
2. **Recent High-Spenders** - Recent active high-value customers
3. **Frequent Low-Spenders** - Regular but budget-conscious
4. **At-Risk Churners** - Haven't purchased recently
5. **Budget Shoppers** - Occasional low-value purchases

### Business Insights

- Highest revenue segment identified
- At-risk customer segments flagged
- Premium customer profiles defined
- Marketing strategies per segment

## 📱 Web Interface

The project includes a modern web dashboard that displays:
- Real-time clustering results
- Interactive charts (Chart.js)
- Customer segment profiles
- Marketing recommendations
- Business insights

## 🔬 Technical Details

### Data Preprocessing
- Missing value imputation (median for numerical, mode for categorical)
- Outlier detection and handling (IQR method)
- Feature scaling (StandardScaler)
- Categorical encoding (LabelEncoder)

### Feature Engineering
- RFM Features (Recency, Frequency, Monetary)
- Customer Value Score
- Engagement Score
- Risk Score
- Purchase Velocity
- Average Order Value

### Cluster Optimization
- Elbow Method (inertia)
- Silhouette Score analysis
- Davies-Bouldin Index
- Calinski-Harabasz Score

### Dimensionality Reduction
- PCA (Principal Component Analysis)
- t-SNE for visualization

## 📝 Business Recommendations

### Premium Loyalists
- VIP loyalty program with exclusive benefits
- Early access to new products
- Personalized thank-you gifts
- Dedicated customer service

### At-Risk Churners
- Win-back email campaigns
- Special comeback discounts
- Proactive outreach

### Frequent Low-Spenders
- Upselling campaigns
- Bundle deals
- Volume-based discounts

## 🏆 Advanced Features

- Autoencoder-based clustering (optional)
- Feature importance analysis
- Time-based segmentation
- Customer lifetime value grouping

## 📚 Technologies Used

- **Python 3.8+**
- **Pandas & NumPy** - Data manipulation
- **Scikit-learn** - Machine learning
- **SciPy** - Hierarchical clustering
- **Matplotlib & Seaborn** - Static visualizations
- **Plotly** - Interactive charts
- **Flask** - Web API
- **Chart.js** - Frontend charts

## 📄 License

This project is for educational purposes.

## 👤 Author

Customer Segmentation Project - Unsupervised Learning

## 🙏 Acknowledgments

- Dataset inspired by real-world retail customer data
- Clustering algorithms based on industry best practices
- Visualization techniques from data science community
