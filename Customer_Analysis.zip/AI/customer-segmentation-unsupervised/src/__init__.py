# Customer Segmentation Project
# Advanced Unsupervised Machine Learning

__version__ = "1.0.0"
__author__ = "Customer Segmentation Team"
