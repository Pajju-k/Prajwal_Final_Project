"""
Data Preprocessing Module
Handles data cleaning, transformation, and feature engineering
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
import warnings
warnings.filterwarnings('ignore')


class DataPreprocessor:
    """Data preprocessing pipeline for customer segmentation"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.imputer = SimpleImputer(strategy='median')
        
    def load_data(self, filepath):
        """Load data from CSV file"""
        df = pd.read_csv(filepath)
        print(f"Data loaded: {df.shape[0]} rows, {df.shape[1]} columns")
        return df
    
    def handle_missing_values(self, df):
        """Handle missing values in the dataset"""
        print("\n=== Handling Missing Values ===")
        print(f"Missing values before:\n{df.isnull().sum()}")
        
        # For numerical columns, use median imputation
        numerical_cols = df.select_dtypes(include=[np.number]).columns
        for col in numerical_cols:
            if df[col].isnull().sum() > 0:
                median_val = df[col].median()
                df[col].fillna(median_val, inplace=True)
        
        # For categorical columns, use mode imputation
        categorical_cols = df.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            if df[col].isnull().sum() > 0:
                mode_val = df[col].mode()[0]
                df[col].fillna(mode_val, inplace=True)
        
        print(f"Missing values after:\n{df.isnull().sum()}")
        return df
    
    def detect_outliers(self, df, method='iqr', threshold=1.5):
        """Detect outliers using IQR or Z-score method"""
        print("\n=== Detecting Outliers ===")
        
        outlier_info = {}
        numerical_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numerical_cols:
            if method == 'iqr':
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - threshold * IQR
                upper_bound = Q3 + threshold * IQR
                outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)][col]
                outlier_info[col] = len(outliers)
            elif method == 'zscore':
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                outliers = df[z_scores > threshold][col]
                outlier_info[col] = len(outliers)
        
        for col, count in outlier_info.items():
            print(f"{col}: {count} outliers detected")
        
        return outlier_info
    
    def handle_outliers(self, df, method='capping', threshold=1.5):
        """Handle outliers using capping or removal"""
        print("\n=== Handling Outliers ===")
        
        numerical_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numerical_cols:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - threshold * IQR
            upper_bound = Q3 + threshold * IQR
            
            if method == 'capping':
                df[col] = df[col].clip(lower_bound, upper_bound)
            elif method == 'removal':
                df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
        
        print(f"Data shape after outlier handling: {df.shape}")
        return df
    
    def encode_categorical(self, df):
        """Encode categorical variables"""
        print("\n=== Encoding Categorical Variables ===")
        
        categorical_cols = df.select_dtypes(include=['object']).columns
        
        for col in categorical_cols:
            if col not in ['customer_id', 'product_categories', 'last_purchase_date']:
                le = LabelEncoder()
                df[col + '_encoded'] = le.fit_transform(df[col].astype(str))
                self.label_encoders[col] = le
                print(f"Encoded {col}: {len(le.classes_)} classes")
        
        return df
    
    def feature_engineering(self, df):
        """Create derived features for better segmentation"""
        print("\n=== Feature Engineering ===")
        
        # Age groups
        df['age_group'] = pd.cut(df['age'], 
                                bins=[0, 25, 35, 45, 55, 100], 
                                labels=['18-25', '26-35', '36-45', '46-55', '55+'])
        
        # Income groups
        df['income_group'] = pd.cut(df['income'], 
                                   bins=[0, 30000, 50000, 80000, 150000, float('inf')], 
                                   labels=['Low', 'Lower-Middle', 'Middle', 'Upper-Middle', 'High'])
        
        # Spending groups
        df['spending_group'] = pd.cut(df['spending_score'], 
                                      bins=[0, 20, 40, 60, 80, 100], 
                                      labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'])
        
        # Customer value score (composite metric)
        df['customer_value_score'] = (
            (df['spending_score'] / 100) * 0.4 +
            (df['num_purchases'] / df['num_purchases'].max()) * 0.3 +
            (df['total_amount_spent'] / df['total_amount_spent'].max()) * 0.3
        )
        
        # Engagement score
        df['engagement_score'] = (
            (df['num_purchases'] / df['num_purchases'].max()) * 0.3 +
            (df['tenure'] / df['tenure'].max()) * 0.3 +
            (1 - df['recency'] / df['recency'].max()) * 0.4
        )
        
        # Risk score (higher = more likely to churn)
        df['risk_score'] = (
            (df['recency'] / df['recency'].max()) * 0.4 +
            (df['returns_rate']) * 0.3 +
            (1 - df['discount_sensitivity']) * 0.3
        )
        
        # Purchase frequency category
        df['purchase_frequency'] = pd.cut(df['num_purchases'], 
                                           bins=[0, 3, 8, 15, 50], 
                                           labels=['Rare', 'Occasional', 'Regular', 'Frequent'])
        
        print(f"Created {6} new features")
        return df
    
    def select_features(self, df):
        """Select features for clustering"""
        print("\n=== Selecting Features for Clustering ===")
        
        # Features for clustering (numerical only)
        numerical_features = [
            'age', 'income', 'spending_score', 'num_purchases',
            'avg_purchase_amount', 'total_amount_spent', 'recency', 'tenure',
            'discount_sensitivity', 'returns_rate', 'frequency', 'monetary',
            'avg_inter_purchase_time', 'purchase_velocity', 'average_order_value',
            'estimated_clv', 'customer_value_score', 'engagement_score', 'risk_score'
        ]
        
        # Filter to only existing columns
        features = [f for f in numerical_features if f in df.columns]
        print(f"Selected {len(features)} features: {features}")
        
        return features
    
    def scale_features(self, df, features):
        """Scale features for clustering"""
        print("\n=== Scaling Features ===")
        
        X = df[features].copy()
        
        # Handle any remaining missing values
        X = X.fillna(X.median())
        
        # Standard scaling
        X_scaled = self.scaler.fit_transform(X)
        
        print(f"Scaled {X_scaled.shape[1]} features")
        return X_scaled, features
    
    def preprocess_pipeline(self, filepath):
        """Complete preprocessing pipeline"""
        print("=" * 60)
        print("STARTING DATA PREPROCESSING PIPELINE")
        print("=" * 60)
        
        # Load data
        df = self.load_data(filepath)
        
        # Handle missing values
        df = self.handle_missing_values(df)
        
        # Detect outliers
        outlier_info = self.detect_outliers(df)
        
        # Handle outliers (capping method)
        df = self.handle_outliers(df, method='capping')
        
        # Encode categorical
        df = self.encode_categorical(df)
        
        # Feature engineering
        df = self.feature_engineering(df)
        
        # Select features
        features = self.select_features(df)
        
        # Scale features
        X_scaled, features = self.scale_features(df, features)
        
        print("\n" + "=" * 60)
        print("PREPROCESSING COMPLETE")
        print("=" * 60)
        
        return df, X_scaled, features


if __name__ == "__main__":
    # Test preprocessing
    preprocessor = DataPreprocessor()
    df = preprocessor.load_data('data/raw/customer_data.csv')
    df_processed, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
    print(f"\nFinal processed data shape: {df_processed.shape}")
    print(f"Scaled features shape: {X_scaled.shape}")
