"""
Clustering Module
Implements various unsupervised clustering algorithms
"""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.decomposition import PCA
import warnings
warnings.filterwarnings('ignore')


class ClusterAnalyzer:
    """Main clustering analyzer class"""
    
    def __init__(self):
        self.best_model = None
        self.best_n_clusters = None
        self.best_algorithm = None
        self.results = {}
        
    def kmeans_clustering(self, X, n_clusters_range=range(2, 11)):
        """K-Means clustering with elbow method and silhouette analysis"""
        print("\n" + "="*60)
        print("K-MEANS CLUSTERING")
        print("="*60)
        
        results = {
            'inertias': [],
            'silhouette_scores': [],
            'davies_bouldin_scores': [],
            'calinski_scores': [],
            'models': []
        }
        
        for n_clusters in n_clusters_range:
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10, max_iter=300)
            labels = kmeans.fit_predict(X)
            
            # Calculate metrics
            silhouette = silhouette_score(X, labels)
            davies = davies_bouldin_score(X, labels)
            calinski = calinski_harabasz_score(X, labels)
            
            results['inertias'].append(kmeans.inertia_)
            results['silhouette_scores'].append(silhouette)
            results['davies_bouldin_scores'].append(davies)
            results['calinski_scores'].append(calinski)
            results['models'].append(kmeans)
            
            print(f"n_clusters={n_clusters}: Silhouette={silhouette:.4f}, Davies-Bouldin={davies:.4f}, Calinski={calinski:.2f}")
        
        # Find best number of clusters based on silhouette score
        best_idx = np.argmax(results['silhouette_scores'])
        best_n = list(n_clusters_range)[best_idx]
        
        print(f"\nBest K-Means: n_clusters={best_n} (Silhouette={results['silhouette_scores'][best_idx]:.4f})")
        
        return results, best_n
    
    def hierarchical_clustering(self, X, n_clusters_range=range(2, 11)):
        """Hierarchical (Agglomerative) clustering"""
        print("\n" + "="*60)
        print("HIERARCHICAL CLUSTERING")
        print("="*60)
        
        results = {
            'silhouette_scores': [],
            'davies_bouldin_scores': [],
            'calinski_scores': [],
            'models': []
        }
        
        for n_clusters in n_clusters_range:
            hc = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward')
            labels = hc.fit_predict(X)
            
            # Calculate metrics
            silhouette = silhouette_score(X, labels)
            davies = davies_bouldin_score(X, labels)
            calinski = calinski_harabasz_score(X, labels)
            
            results['silhouette_scores'].append(silhouette)
            results['davies_bouldin_scores'].append(davies)
            results['calinski_scores'].append(calinski)
            results['models'].append(hc)
            
            print(f"n_clusters={n_clusters}: Silhouette={silhouette:.4f}, Davies-Bouldin={davies:.4f}, Calinski={calinski:.2f}")
        
        # Find best number of clusters
        best_idx = np.argmax(results['silhouette_scores'])
        best_n = list(n_clusters_range)[best_idx]
        
        print(f"\nBest Hierarchical: n_clusters={best_n} (Silhouette={results['silhouette_scores'][best_idx]:.4f})")
        
        return results, best_n
    
    def dbscan_clustering(self, X, eps_range=None, min_samples_range=None):
        """DBSCAN clustering"""
        print("\n" + "="*60)
        print("DBSCAN CLUSTERING")
        print("="*60)
        
        if eps_range is None:
            eps_range = [0.3, 0.5, 0.7, 1.0, 1.5]
        if min_samples_range is None:
            min_samples_range = [3, 5, 7, 10]
        
        results = {
            'silhouette_scores': [],
            'davies_bouldin_scores': [],
            'calinski_scores': [],
            'n_clusters': [],
            'noise_points': [],
            'models': [],
            'params': []
        }
        
        for eps in eps_range:
            for min_samples in min_samples_range:
                dbscan = DBSCAN(eps=eps, min_samples=min_samples)
                labels = dbscan.fit_predict(X)
                
                n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
                n_noise = list(labels).count(-1)
                
                if n_clusters < 2 or n_clusters > 10:
                    continue
                
                # Exclude noise points for scoring
                mask = labels != -1
                if sum(mask) < 50:
                    continue
                    
                X_filtered = X[mask]
                labels_filtered = labels[mask]
                
                silhouette = silhouette_score(X_filtered, labels_filtered)
                davies = davies_bouldin_score(X_filtered, labels_filtered)
                calinski = calinski_harabasz_score(X_filtered, labels_filtered)
                
                results['silhouette_scores'].append(silhouette)
                results['davies_bouldin_scores'].append(davies)
                results['calinski_scores'].append(calinski)
                results['n_clusters'].append(n_clusters)
                results['noise_points'].append(n_noise)
                results['models'].append(dbscan)
                results['params'].append({'eps': eps, 'min_samples': min_samples})
                
                print(f"eps={eps}, min_samples={min_samples}: Clusters={n_clusters}, Silhouette={silhouette:.4f}, Noise={n_noise}")
        
        if len(results['silhouette_scores']) == 0:
            print("No valid DBSCAN configuration found")
            return results, 0
        
        # Find best configuration
        best_idx = np.argmax(results['silhouette_scores'])
        best_n = results['n_clusters'][best_idx]
        
        print(f"\nBest DBSCAN: {results['params'][best_idx]} -> n_clusters={best_n}")
        
        return results, best_n
    
    def gmm_clustering(self, X, n_clusters_range=range(2, 11)):
        """Gaussian Mixture Model clustering"""
        print("\n" + "="*60)
        print("GAUSSIAN MIXTURE MODEL CLUSTERING")
        print("="*60)
        
        results = {
            'bic_scores': [],
            'aic_scores': [],
            'silhouette_scores': [],
            'davies_bouldin_scores': [],
            'calinski_scores': [],
            'models': []
        }
        
        for n_clusters in n_clusters_range:
            gmm = GaussianMixture(n_components=n_clusters, random_state=42, n_init=5)
            labels = gmm.fit_predict(X)
            
            # Calculate metrics
            silhouette = silhouette_score(X, labels)
            davies = davies_bouldin_score(X, labels)
            calinski = calinski_harabasz_score(X, labels)
            bic = gmm.bic(X)
            aic = gmm.aic(X)
            
            results['bic_scores'].append(bic)
            results['aic_scores'].append(aic)
            results['silhouette_scores'].append(silhouette)
            results['davies_bouldin_scores'].append(davies)
            results['calinski_scores'].append(calinski)
            results['models'].append(gmm)
            
            print(f"n_clusters={n_clusters}: Silhouette={silhouette:.4f}, BIC={bic:.2f}, AIC={aic:.2f}")
        
        # Find best number of clusters (using BIC - lower is better)
        best_idx = np.argmin(results['bic_scores'])
        best_n = list(n_clusters_range)[best_idx]
        
        print(f"\nBest GMM: n_clusters={best_n} (BIC={results['bic_scores'][best_idx]:.2f})")
        
        return results, best_n
    
    def compare_algorithms(self, X):
        """Compare all clustering algorithms"""
        print("\n" + "="*60)
        print("ALGORITHM COMPARISON")
        print("="*60)
        
        # Run all algorithms
        kmeans_results, kmeans_best = self.kmeans_clustering(X)
        hc_results, hc_best = self.hierarchical_clustering(X)
        dbscan_results, dbscan_best = self.dbscan_clustering(X)
        gmm_results, gmm_best = self.gmm_clustering(X)
        
        # Summary comparison
        comparison = {
            'Algorithm': ['K-Means', 'Hierarchical', 'DBSCAN', 'GMM'],
            'Best_n_Clusters': [kmeans_best, hc_best, dbscan_best, gmm_best],
            'Silhouette_Score': [
                max(kmeans_results['silhouette_scores']),
                max(hc_results['silhouette_scores']),
                max(dbscan_results['silhouette_scores']) if dbscan_results['silhouette_scores'] else 0,
                max(gmm_results['silhouette_scores'])
            ],
            'Davies_Bouldin_Score': [
                min(kmeans_results['davies_bouldin_scores']),
                min(hc_results['davies_bouldin_scores']),
                min(dbscan_results['davies_bouldin_scores']) if dbscan_results['davies_bouldin_scores'] else 0,
                min(gmm_results['davies_bouldin_scores'])
            ]
        }
        
        comparison_df = pd.DataFrame(comparison)
        print("\n" + "="*60)
        print("ALGORITHM COMPARISON SUMMARY")
        print("="*60)
        print(comparison_df.to_string(index=False))
        
        # Determine best algorithm
        best_silhouette_idx = np.argmax(comparison['Silhouette_Score'])
        best_algorithm = comparison['Algorithm'][best_silhouette_idx]
        
        print(f"\nBest Algorithm: {best_algorithm} (Silhouette Score: {comparison['Silhouette_Score'][best_silhouette_idx]:.4f})")
        
        self.results = {
            'kmeans': kmeans_results,
            'hierarchical': hc_results,
            'dbscan': dbscan_results,
            'gmm': gmm_results,
            'comparison': comparison_df
        }
        
        return self.results
    
    def fit_final_model(self, X, algorithm='kmeans', n_clusters=5):
        """Fit final model with best parameters"""
        print(f"\nFitting final {algorithm} model with {n_clusters} clusters...")
        
        if algorithm == 'kmeans':
            model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            labels = model.fit_predict(X)
            self.best_model = model
        elif algorithm == 'hierarchical':
            model = AgglomerativeClustering(n_clusters=n_clusters, linkage='ward')
            labels = model.fit_predict(X)
            self.best_model = model
        elif algorithm == 'gmm':
            model = GaussianMixture(n_components=n_clusters, random_state=42, n_init=5)
            labels = model.fit_predict(X)
            self.best_model = model
        else:
            raise ValueError(f"Unknown algorithm: {algorithm}")
        
        self.best_n_clusters = n_clusters
        self.best_algorithm = algorithm
        
        # Calculate final metrics
        silhouette = silhouette_score(X, labels)
        davies = davies_bouldin_score(X, labels)
        calinski = calinski_harabasz_score(X, labels)
        
        print(f"Final Model Metrics:")
        print(f"  Silhouette Score: {silhouette:.4f}")
        print(f"  Davies-Bouldin Index: {davies:.4f}")
        print(f"  Calinski-Harabasz Score: {calinski:.2f}")
        
        return labels
    
    def apply_pca(self, X, n_components=2):
        """Apply PCA for dimensionality reduction"""
        pca = PCA(n_components=n_components)
        X_pca = pca.fit_transform(X)
        
        print(f"\nPCA Explained Variance Ratio: {pca.explained_variance_ratio_}")
        print(f"Total Variance Explained: {sum(pca.explained_variance_ratio_)*100:.2f}%")
        
        return X_pca, pca
    
    def apply_tsne(self, X, n_components=2, perplexity=30):
        """Apply t-SNE for dimensionality reduction"""
        from sklearn.manifold import TSNE
        
        tsne = TSNE(n_components=n_components, perplexity=perplexity, random_state=42)
        X_tsne = tsne.fit_transform(X)
        
        return X_tsne, tsne


if __name__ == "__main__":
    # Test clustering
    from data_preprocessing import DataPreprocessor
    
    preprocessor = DataPreprocessor()
    df, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
    
    # Run clustering analysis
    analyzer = ClusterAnalyzer()
    results = analyzer.compare_algorithms(X_scaled)
    
    # Fit final model
    labels = analyzer.fit_final_model(X_scaled, algorithm='kmeans', n_clusters=5)
    print(f"\nCluster distribution: {np.bincount(labels)}")
