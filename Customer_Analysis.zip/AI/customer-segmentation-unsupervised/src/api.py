"""
Flask API for Customer Segmentation
Serves analysis results to frontend
"""

from flask import Flask, jsonify, request, send_file, render_template
from flask_cors import CORS
import pandas as pd
import numpy as np
import json
import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.dirname(__file__))

try:
    from src.data_generator import generate_customer_data, add_rfm_features
    from src.data_preprocessing import DataPreprocessor
    from src.clustering import ClusterAnalyzer as MLClusterAnalyzer
    from src.cluster_analysis import ClusterAnalyzer as BizClusterAnalyzer
    from src.visualization import Visualizer
except ImportError:
    # Try alternative import paths
    from data_generator import generate_customer_data, add_rfm_features
    from data_preprocessing import DataPreprocessor
    from clustering import ClusterAnalyzer as MLClusterAnalyzer
    from cluster_analysis import ClusterAnalyzer as BizClusterAnalyzer
    from visualization import Visualizer

app = Flask(__name__)
CORS(app)

# Global variables to store analysis results
analysis_results = {
    'data': None,
    'cluster_labels': None,
    'cluster_profiles': None,
    'customer_types': None,
    'business_insights': None,
    'recommendations': None,
    'metrics': None
}


@app.route('/')
def index():
    """Serve the frontend HTML"""
    try:
        # Get the base directory (project root)
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        index_path = os.path.join(base_dir, 'index.html')
        
        if os.path.exists(index_path):
            return send_file(index_path)
        
        # Fallback: try current directory
        if os.path.exists('index.html'):
            return send_file('index.html')
        
        # If not found, return API info
        return jsonify({
            'message': 'Customer Segmentation API',
            'version': '1.0',
            'endpoints': [
                '/api/generate-data',
                '/api/analyze',
                '/api/overview',
                '/api/clusters',
                '/api/insights',
                '/api/recommendations'
            ],
            'note': 'Frontend not found at: ' + index_path
        })
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/generate-data', methods=['POST'])
def generate_data():
    """Generate or regenerate customer data"""
    try:
        n_customers = request.json.get('n_customers', 6000) if request.json else 6000
        
        print(f"Generating data for {n_customers} customers...")
        
        # Generate data
        df = generate_customer_data(n_customers=n_customers, random_seed=42)
        df = add_rfm_features(df)
        
        # Save raw data
        os.makedirs('data/raw', exist_ok=True)
        df.to_csv('data/raw/customer_data.csv', index=False)
        
        # Store in global
        analysis_results['data'] = df
        
        return jsonify({
            'success': True,
            'message': f'Generated {len(df)} customer records',
            'columns': list(df.columns),
            'shape': df.shape
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/analyze', methods=['POST'])
def run_analysis():
    """Run full analysis pipeline"""
    try:
        data = request.json
        n_clusters = data.get('n_clusters', 5) if data else 5
        algorithm = data.get('algorithm', 'kmeans') if data else 'kmeans'
        
        print(f"Running analysis with {algorithm} and {n_clusters} clusters...")
        
        # Load data
        if analysis_results['data'] is None:
            df = pd.read_csv('data/raw/customer_data.csv')
            analysis_results['data'] = df
        else:
            df = analysis_results['data']
        
        # Preprocess
        preprocessor = DataPreprocessor()
        df_processed, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
        
        # ML Clustering
        ml_analyzer = MLClusterAnalyzer()
        
        # Compare algorithms first
        comparison_results = ml_analyzer.compare_algorithms(X_scaled)
        
        # Fit final model
        labels = ml_analyzer.fit_final_model(X_scaled, algorithm=algorithm, n_clusters=n_clusters)
        
        # Store labels
        analysis_results['cluster_labels'] = labels
        df_processed['cluster'] = labels
        analysis_results['data'] = df_processed
        
        # Business Analysis
        biz_analyzer = BizClusterAnalyzer()
        cluster_profiles = biz_analyzer.analyze_clusters(df_processed, labels, features)
        customer_types = biz_analyzer.define_customer_types()
        business_insights = biz_analyzer.generate_business_insights(df_processed)
        recommendations = biz_analyzer.generate_recommendations()
        
        # Store results
        analysis_results['cluster_profiles'] = cluster_profiles
        analysis_results['customer_types'] = customer_types
        analysis_results['business_insights'] = business_insights
        analysis_results['recommendations'] = recommendations
        
        # Calculate metrics
        from sklearn.metrics import silhouette_score, davies_bouldin_score
        silhouette = silhouette_score(X_scaled, labels)
        davies = davies_bouldin_score(X_scaled, labels)
        
        analysis_results['metrics'] = {
            'silhouette_score': float(silhouette),
            'davies_bouldin_score': float(davies),
            'n_clusters': n_clusters,
            'algorithm': algorithm,
            'n_samples': len(labels)
        }
        
        # Generate visualizations
        viz = Visualizer(output_dir='results')
        viz.generate_all_visualizations(df_processed, X_scaled, labels, cluster_profiles)
        
        return jsonify({
            'success': True,
            'message': 'Analysis complete',
            'metrics': analysis_results['metrics'],
            'cluster_count': n_clusters
        })
        
    except Exception as e:
        import traceback
        return jsonify({'success': False, 'error': str(e), 'trace': traceback.format_exc()}), 500


@app.route('/api/overview', methods=['GET'])
def get_overview():
    """Get data overview"""
    try:
        if analysis_results['data'] is None:
            df = pd.read_csv('data/raw/customer_data.csv')
        else:
            df = analysis_results['data']
        
        overview = {
            'total_customers': len(df),
            'columns': list(df.columns),
            'numerical_summary': df.describe().to_dict(),
            'missing_values': df.isnull().sum().to_dict()
        }
        
        return jsonify(overview)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/clusters', methods=['GET'])
def get_clusters():
    """Get cluster information"""
    try:
        if analysis_results['cluster_profiles'] is None:
            return jsonify({'error': 'No analysis results. Run /api/analyze first'}), 400
        
        clusters = []
        for cluster_id, profile in analysis_results['cluster_profiles'].items():
            customer_type = analysis_results['customer_types'].get(cluster_id, {})
            
            cluster_info = {
                'cluster_id': cluster_id,
                'size': profile['size'],
                'percentage': round(profile['percentage'], 2),
                'avg_age': round(profile['avg_age'], 1),
                'avg_income': round(profile['avg_income'], 0),
                'avg_spending_score': round(profile['avg_spending_score'], 1),
                'avg_purchases': round(profile['avg_num_purchases'], 1),
                'avg_total_spent': round(profile['avg_total_spent'], 2),
                'avg_clv': round(profile['avg_estimated_clv'], 2),
                'avg_recency': round(profile['avg_recency'], 1),
                'risk_score': round(profile['avg_risk_score'], 3),
                'customer_type': customer_type.get('customer_type', 'Unknown'),
                'description': customer_type.get('description', ''),
                'priority': customer_type.get('priority', 'Medium')
            }
            clusters.append(cluster_info)
        
        return jsonify({'clusters': clusters})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/insights', methods=['GET'])
def get_insights():
    """Get business insights"""
    try:
        if analysis_results['business_insights'] is None:
            return jsonify({'error': 'No insights available. Run /api/analyze first'}), 400
        
        insights = analysis_results['business_insights']
        
        # Convert numpy types to Python types
        def convert(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, dict):
                return {k: convert(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert(i) for i in obj]
            return obj
        
        insights = convert(insights)
        
        return jsonify(insights)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/recommendations', methods=['GET'])
def get_recommendations():
    """Get marketing recommendations"""
    try:
        if analysis_results['recommendations'] is None:
            return jsonify({'error': 'No recommendations. Run /api/analyze first'}), 400
        
        recommendations = analysis_results['recommendations']
        
        # Convert to JSON-serializable format
        recs = []
        for cluster_id, rec in recommendations.items():
            rec_copy = {
                'cluster_id': int(cluster_id),
                'customer_type': rec['customer_type'],
                'segment_size': rec['segment_size'],
                'segment_percentage': round(rec['segment_percentage'], 2),
                'avg_revenue': round(rec['avg_revenue'], 2),
                'priority': rec['priority'],
                'marketing_tactics': rec['marketing_tactics'],
                'personalized_offers': rec['personalized_offers'],
                'retention_strategy': rec['retention_strategy']
            }
            recs.append(rec_copy)
        
        return jsonify({'recommendations': recs})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get clustering metrics"""
    try:
        if analysis_results['metrics'] is None:
            return jsonify({'error': 'No metrics available. Run /api/analyze first'}), 400
        
        return jsonify(analysis_results['metrics'])
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/distribution', methods=['GET'])
def get_distribution():
    """Get cluster distribution data"""
    try:
        if analysis_results['data'] is None or analysis_results['cluster_labels'] is None:
            return jsonify({'error': 'No data available'}), 400
        
        df = analysis_results['data']
        labels = analysis_results['cluster_labels']
        
        distribution = pd.Series(labels).value_counts().sort_index().to_dict()
        distribution = {int(k): int(v) for k, v in distribution.items()}
        
        return jsonify({
            'distribution': distribution,
            'total': len(labels)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    # Ensure data directory exists
    os.makedirs('data/raw', exist_ok=True)
    os.makedirs('data/processed', exist_ok=True)
    os.makedirs('results', exist_ok=True)
    
    print("=" * 60)
    print("Customer Segmentation API")
    print("=" * 60)
    print("Starting server at http://localhost:5000")
    print("Available endpoints:")
    print("  - GET  /                   - API info")
    print("  - POST /api/generate-data - Generate customer data")
    print("  - POST /api/analyze       - Run clustering analysis")
    print("  - GET  /api/overview      - Data overview")
    print("  - GET  /api/clusters      - Cluster information")
    print("  - GET  /api/insights      - Business insights")
    print("  - GET  /api/recommendations - Marketing recommendations")
    print("  - GET  /api/metrics       - Clustering metrics")
    print("  - GET  /api/distribution  - Cluster distribution")
    print("=" * 60)
    
    app.run(debug=True, port=5000, host='0.0.0.0')
