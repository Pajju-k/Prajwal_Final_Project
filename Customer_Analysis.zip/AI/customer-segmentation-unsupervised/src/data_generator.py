"""
Data Generator Module
Generates realistic customer data for segmentation analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

def generate_customer_data(n_customers=6000, random_seed=42):
    """
    Generate realistic customer data with various features
    
    Parameters:
    -----------
    n_customers : int
        Number of customers to generate
    random_seed : int
        Random seed for reproducibility
    
    Returns:
    --------
    pd.DataFrame
        Generated customer data
    """
    np.random.seed(random_seed)
    
    # Generate customer IDs
    customer_ids = [f'CUST_{i:05d}' for i in range(1, n_customers + 1)]
    
    # Age distribution (18-75 years)
    age = np.random.normal(40, 12, n_customers)
    age = np.clip(age, 18, 75).astype(int)
    
    # Gender (weighted towards female slightly)
    gender = np.random.choice(['Male', 'Female', 'Other'], n_customers, p=[0.45, 0.50, 0.05])
    
    # Income distribution (annual income in USD)
    # Using a log-normal distribution to get realistic income spread
    income = np.random.lognormal(10.5, 0.6, n_customers)
    income = np.clip(income, 15000, 500000).astype(int)
    
    # Spending Score (1-100)
    # Higher correlation with income but with noise
    spending_score = np.random.normal(50, 20, n_customers)
    spending_score = (spending_score + (income / 10000)).astype(int)
    spending_score = np.clip(spending_score, 1, 100)
    
    # Product categories purchased (multi-select)
    product_categories = ['Electronics', 'Clothing', 'Food', 'Home', 'Sports', 'Books', 'Beauty', 'Toys']
    
    def get_categories(n):
        n_cats = np.random.randint(1, 5, n)
        cats = []
        for i in range(n):
            selected = np.random.choice(product_categories, n_cats[i], replace=False)
            cats.append(', '.join(selected))
        return cats
    
    product_categories_purchased = get_categories(n_customers)
    
    # Number of purchases per year
    num_purchases = np.random.exponential(5, n_customers).astype(int)
    num_purchases = np.clip(num_purchases, 1, 50)
    
    # Average purchase amount
    avg_purchase_amount = np.random.lognormal(4.5, 0.8, n_customers)
    avg_purchase_amount = np.clip(avg_purchase_amount, 10, 5000).round(2)
    
    # Total amount spent
    total_amount_spent = (num_purchases * avg_purchase_amount * np.random.uniform(0.8, 1.2, n_customers)).round(2)
    
    # Recency (days since last purchase)
    recency = np.random.exponential(60, n_customers).astype(int)
    recency = np.clip(recency, 1, 365)
    
    # Customer tenure (days since first purchase)
    tenure = np.random.exponential(365, n_customers).astype(int)
    tenure = np.clip(tenure, 30, 3000)
    
    # Preferred shopping channel
    channel = np.random.choice(['Online', 'In-Store', 'Mobile App', 'Multi-Channel'], 
                               n_customers, p=[0.35, 0.30, 0.20, 0.15])
    
    # Discount sensitivity (percentage of purchases using discount)
    discount_sensitivity = np.random.uniform(0, 1, n_customers).round(2)
    
    # Returns rate (percentage of purchases returned)
    returns_rate = np.random.exponential(0.05, n_customers)
    returns_rate = np.clip(returns_rate, 0, 0.5).round(3)
    
    # Last purchase date
    reference_date = datetime(2024, 1, 1)
    last_purchase_date = [reference_date - timedelta(days=int(r)) for r in recency]
    
    # Create DataFrame
    df = pd.DataFrame({
        'customer_id': customer_ids,
        'age': age,
        'gender': gender,
        'income': income,
        'spending_score': spending_score,
        'product_categories': product_categories_purchased,
        'num_purchases': num_purchases,
        'avg_purchase_amount': avg_purchase_amount,
        'total_amount_spent': total_amount_spent,
        'recency': recency,
        'tenure': tenure,
        'preferred_channel': channel,
        'discount_sensitivity': discount_sensitivity,
        'returns_rate': returns_rate,
        'last_purchase_date': last_purchase_date
    })
    
    # Add some missing values (realistic scenario)
    n_missing_income = int(n_customers * 0.02)
    n_missing_age = int(n_customers * 0.01)
    
    missing_income_idx = np.random.choice(df.index, n_missing_income, replace=False)
    missing_age_idx = np.random.choice(df.index, n_missing_age, replace=False)
    
    df.loc[missing_income_idx, 'income'] = np.nan
    df.loc[missing_age_idx, 'age'] = np.nan
    
    # Add some outliers (realistic scenario)
    n_outliers = int(n_customers * 0.01)
    outlier_idx = np.random.choice(df.index, n_outliers, replace=False)
    df.loc[outlier_idx, 'total_amount_spent'] = df.loc[outlier_idx, 'total_amount_spent'] * 10
    df.loc[outlier_idx, 'num_purchases'] = df.loc[outlier_idx, 'num_purchases'] * 5
    
    return df


def add_rfm_features(df):
    """
    Add RFM (Recency, Frequency, Monetary) features
    
    Parameters:
    -----------
    df : pd.DataFrame
        Customer data
    
    Returns:
    --------
    pd.DataFrame
        DataFrame with RFM features
    """
    # Recency is already in the dataset
    # Frequency: number of purchases
    df['frequency'] = df['num_purchases']
    
    # Monetary: total amount spent
    df['monetary'] = df['total_amount_spent']
    
    # Additional derived features
    # Average inter-purchase time
    df['avg_inter_purchase_time'] = (df['tenure'] / df['num_purchases']).round(2)
    
    # Purchase velocity (purchases per month)
    df['purchase_velocity'] = (df['num_purchases'] / (df['tenure'] / 30)).round(2)
    
    # Average order value
    df['average_order_value'] = (df['total_amount_spent'] / df['num_purchases']).round(2)
    
    # Customer lifetime value (estimated)
    # Using a simple CLV formula
    df['estimated_clv'] = (df['avg_purchase_amount'] * df['num_purchases'] * 
                          (1 - df['returns_rate']) * 12).round(2)  # Annualized
    
    return df


def save_data(df, output_dir='data/raw'):
    """Save generated data to CSV"""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, 'customer_data.csv')
    df.to_csv(filepath, index=False)
    print(f"Data saved to {filepath}")
    return filepath


if __name__ == "__main__":
    # Generate data
    print("Generating customer data...")
    df = generate_customer_data(n_customers=6000, random_seed=42)
    
    # Add RFM features
    print("Adding RFM features...")
    df = add_rfm_features(df)
    
    # Save raw data
    print("Saving data...")
    save_data(df, output_dir='data/raw')
    
    print(f"\nDataset shape: {df.shape}")
    print(f"\nColumn types:\n{df.dtypes}")
    print(f"\nMissing values:\n{df.isnull().sum()}")
    print(f"\nBasic statistics:\n{df.describe()}")
