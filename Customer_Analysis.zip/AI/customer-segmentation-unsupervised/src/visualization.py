"""
Visualization Module
Generates various plots and charts for EDA and cluster visualization
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")


class Visualizer:
    """Generate visualizations for customer segmentation"""
    
    def __init__(self, output_dir='results'):
        self.output_dir = output_dir
        import os
        os.makedirs(output_dir, exist_ok=True)
        
    def plot_distribution(self, df, columns, save=True):
        """Plot distribution of numerical features"""
        n_cols = len(columns)
        fig, axes = plt.subplots(n_cols, 1, figsize=(12, 4*n_cols))
        
        if n_cols == 1:
            axes = [axes]
        
        for i, col in enumerate(columns):
            axes[i].hist(df[col].dropna(), bins=50, edgecolor='black', alpha=0.7)
            axes[i].set_title(f'Distribution of {col}')
            axes[i].set_xlabel(col)
            axes[i].set_ylabel('Frequency')
        
        plt.tight_layout()
        if save:
            plt.savefig(f'{self.output_dir}/distribution_plots.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/distribution_plots.png")
        plt.close()
        
    def plot_correlation_heatmap(self, df, features, save=True):
        """Plot correlation heatmap"""
        corr_matrix = df[features].corr()
        
        plt.figure(figsize=(14, 12))
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='coolwarm', 
                   center=0, fmt='.2f', square=True, linewidths=0.5)
        plt.title('Feature Correlation Heatmap', fontsize=14)
        
        if save:
            plt.savefig(f'{self.output_dir}/correlation_heatmap.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/correlation_heatmap.png")
        plt.close()
        
    def plot_elbow_method(self, inertias, save=True):
        """Plot elbow method chart"""
        plt.figure(figsize=(10, 6))
        plt.plot(range(2, len(inertias)+2), inertias, 'bo-', linewidth=2, markersize=8)
        plt.xlabel('Number of Clusters (k)', fontsize=12)
        plt.ylabel('Inertia (Within-cluster sum of squares)', fontsize=12)
        plt.title('Elbow Method for Optimal k', fontsize=14)
        plt.grid(True, alpha=0.3)
        
        if save:
            plt.savefig(f'{self.output_dir}/elbow_method.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/elbow_method.png")
        plt.close()
        
    def plot_silhouette_scores(self, scores, labels, save=True):
        """Plot silhouette scores comparison"""
        plt.figure(figsize=(10, 6))
        x = range(2, len(scores)+2)
        plt.plot(x, scores, 'go-', linewidth=2, markersize=8)
        plt.xlabel('Number of Clusters (k)', fontsize=12)
        plt.ylabel('Silhouette Score', fontsize=12)
        plt.title('Silhouette Score Analysis', fontsize=14)
        plt.grid(True, alpha=0.3)
        
        # Mark best
        best_k = list(x)[np.argmax(scores)]
        best_score = max(scores)
        plt.axvline(x=best_k, color='r', linestyle='--', alpha=0.7)
        plt.annotate(f'Best k={best_k}\nScore={best_score:.3f}', 
                    xy=(best_k, best_score), xytext=(best_k+1, best_score-0.05),
                    fontsize=10, arrowprops=dict(arrowstyle='->', color='red'))
        
        if save:
            plt.savefig(f'{self.output_dir}/silhouette_scores.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/silhouette_scores.png")
        plt.close()
        
    def plot_pca_2d(self, X, labels, save=True):
        """Plot 2D PCA visualization of clusters"""
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(X)
        
        plt.figure(figsize=(12, 8))
        scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap='viridis', 
                             alpha=0.6, s=50, edgecolors='white', linewidth=0.5)
        plt.colorbar(scatter, label='Cluster')
        plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% variance)', fontsize=12)
        plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% variance)', fontsize=12)
        plt.title('Customer Segments - PCA Visualization', fontsize=14)
        
        if save:
            plt.savefig(f'{self.output_dir}/pca_2d_clusters.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/pca_2d_clusters.png")
        plt.close()
        
        return X_pca, pca
        
    def plot_tsne_2d(self, X, labels, perplexity=30, save=True):
        """Plot 2D t-SNE visualization of clusters"""
        tsne = TSNE(n_components=2, perplexity=perplexity, random_state=42, max_iter=1000)
        X_tsne = tsne.fit_transform(X)
        
        plt.figure(figsize=(12, 8))
        scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=labels, cmap='viridis', 
                             alpha=0.6, s=50, edgecolors='white', linewidth=0.5)
        plt.colorbar(scatter, label='Cluster')
        plt.xlabel('t-SNE Dimension 1', fontsize=12)
        plt.ylabel('t-SNE Dimension 2', fontsize=12)
        plt.title(f'Customer Segments - t-SNE Visualization (perplexity={perplexity})', fontsize=14)
        
        if save:
            plt.savefig(f'{self.output_dir}/tsne_2d_clusters.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/tsne_2d_clusters.png")
        plt.close()
        
        return X_tsne, tsne
        
    def plot_cluster_sizes(self, df, save=True):
        """Plot cluster size distribution"""
        cluster_counts = df['cluster'].value_counts().sort_index()
        
        plt.figure(figsize=(10, 6))
        bars = plt.bar(cluster_counts.index, cluster_counts.values, color=plt.cm.viridis(np.linspace(0, 1, len(cluster_counts))))
        
        for bar, count in zip(bars, cluster_counts.values):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 20, 
                    f'{count}\n({count/len(df)*100:.1f}%)', 
                    ha='center', va='bottom', fontsize=10)
        
        plt.xlabel('Cluster', fontsize=12)
        plt.ylabel('Number of Customers', fontsize=12)
        plt.title('Customer Distribution by Cluster', fontsize=14)
        plt.xticks(cluster_counts.index)
        
        if save:
            plt.savefig(f'{self.output_dir}/cluster_sizes.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/cluster_sizes.png")
        plt.close()
        
    def plot_cluster_profiles(self, df, cluster_profile, save=True):
        """Plot cluster profiles - radar chart"""
        features_to_plot = ['avg_age', 'avg_income', 'avg_spending_score', 
                           'avg_num_purchases', 'avg_total_spent', 'avg_engagement_score']
        
        # Normalize features for radar chart
        normalized_features = {}
        for cluster_id, profile in cluster_profile.items():
            normalized_features[cluster_id] = {
                'Age': profile['avg_age'] / 100,
                'Income': profile['avg_income'] / 200000,
                'Spending': profile['avg_spending_score'] / 100,
                'Purchases': profile['avg_num_purchases'] / 20,
                'Total Spent': profile['avg_total_spent'] / 50000,
                'Engagement': profile['avg_engagement_score']
            }
        
        # Bar chart comparison
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()
        
        feature_names = list(normalized_features[0].keys())
        
        for idx, feature in enumerate(feature_names):
            ax = axes[idx]
            values = [normalized_features[c][feature] for c in normalized_features.keys()]
            bars = ax.bar(range(len(values)), values, color=plt.cm.viridis(np.linspace(0, 1, len(values))))
            ax.set_title(f'{feature} by Cluster')
            ax.set_xlabel('Cluster')
            ax.set_ylabel('Normalized Value')
            ax.set_xticks(range(len(values)))
        
        plt.tight_layout()
        if save:
            plt.savefig(f'{self.output_dir}/cluster_profiles.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/cluster_profiles.png")
        plt.close()
        
    def plot_cluster_comparison(self, df, save=True):
        """Plot comparison of cluster characteristics"""
        numerical_cols = ['age', 'income', 'spending_score', 'num_purchases', 
                         'total_amount_spent', 'recency', 'estimated_clv']
        
        fig, axes = plt.subplots(3, 3, figsize=(15, 12))
        axes = axes.flatten()
        
        for idx, col in enumerate(numerical_cols):
            ax = axes[idx]
            df.boxplot(column=col, by='cluster', ax=ax)
            ax.set_title(f'{col} by Cluster')
            ax.set_xlabel('Cluster')
            ax.set_ylabel(col)
        
        # Remove extra subplots
        for idx in range(len(numerical_cols), len(axes)):
            fig.delaxes(axes[idx])
        
        plt.suptitle('Cluster Characteristics Comparison', fontsize=14, y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/cluster_comparison.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/cluster_comparison.png")
        plt.close()
        
    def plot_revenue_by_cluster(self, df, save=True):
        """Plot revenue contribution by cluster"""
        cluster_revenue = df.groupby('cluster')['total_amount_spent'].sum()
        
        plt.figure(figsize=(10, 8))
        colors = plt.cm.viridis(np.linspace(0, 1, len(cluster_revenue)))
        
        wedges, texts, autotexts = plt.pie(cluster_revenue.values, 
                                           labels=[f'Cluster {i}' for i in cluster_revenue.index],
                                           autopct='%1.1f%%', colors=colors, explode=[0.02]*len(cluster_revenue))
        
        plt.setp(autotexts, size=10, weight='bold')
        plt.setp(texts, size=11)
        plt.title('Revenue Distribution by Cluster', fontsize=14)
        
        if save:
            plt.savefig(f'{self.output_dir}/revenue_by_cluster.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/revenue_by_cluster.png")
        plt.close()
        
    def plot_demographics(self, df, save=True):
        """Plot demographic distributions by cluster"""
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        
        # Gender by cluster
        gender_cluster = pd.crosstab(df['cluster'], df['gender'], normalize='index') * 100
        gender_cluster.plot(kind='bar', ax=axes[0], colormap='Set2')
        axes[0].set_title('Gender Distribution by Cluster')
        axes[0].set_xlabel('Cluster')
        axes[0].set_ylabel('Percentage')
        axes[0].legend(title='Gender')
        axes[0].tick_params(axis='x', rotation=0)
        
        # Preferred channel by cluster
        channel_cluster = pd.crosstab(df['cluster'], df['preferred_channel'], normalize='index') * 100
        channel_cluster.plot(kind='bar', ax=axes[1], colormap='Set3')
        axes[1].set_title('Preferred Channel by Cluster')
        axes[1].set_xlabel('Cluster')
        axes[1].set_ylabel('Percentage')
        axes[1].legend(title='Channel', bbox_to_anchor=(1.05, 1))
        axes[1].tick_params(axis='x', rotation=0)
        
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/demographics_by_cluster.png', dpi=150, bbox_inches='tight')
            print(f"Saved: {self.output_dir}/demographics_by_cluster.png")
        plt.close()
        
    def generate_all_visualizations(self, df, X, labels, cluster_profile):
        """Generate all visualizations"""
        print("\n" + "="*60)
        print("GENERATING VISUALIZATIONS")
        print("="*60)
        
        # Distribution plots
        numerical_cols = ['age', 'income', 'spending_score', 'num_purchases', 'total_amount_spent']
        self.plot_distribution(df, numerical_cols)
        
        # Correlation heatmap
        features = ['age', 'income', 'spending_score', 'num_purchases', 
                   'avg_purchase_amount', 'total_amount_spent', 'recency', 'tenure']
        self.plot_correlation_heatmap(df, features)
        
        # Cluster visualizations
        self.plot_cluster_sizes(df)
        self.plot_cluster_comparison(df)
        self.plot_revenue_by_cluster(df)
        self.plot_demographics(df)
        self.plot_cluster_profiles(df, cluster_profile)
        
        # Dimensionality reduction
        self.plot_pca_2d(X, labels)
        self.plot_tsne_2d(X, labels)
        
        print("\nAll visualizations saved to:", self.output_dir)


if __name__ == "__main__":
    # Test visualization
    from data_preprocessing import DataPreprocessor
    from clustering import ClusterAnalyzer
    
    # Load and preprocess data
    preprocessor = DataPreprocessor()
    df, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
    
    # Run clustering
    ml_analyzer = ClusterAnalyzer()
    labels = ml_analyzer.fit_final_model(X_scaled, algorithm='kmeans', n_clusters=5)
    
    df['cluster'] = labels
    
    # Generate visualizations
    viz = Visualizer(output_dir='results')
    viz.generate_all_visualizations(df, X_scaled, labels, {})
