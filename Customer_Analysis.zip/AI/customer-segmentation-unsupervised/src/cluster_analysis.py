"""
Cluster Analysis and Business Insights Module
Analyzes clusters and generates business recommendations
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


class ClusterAnalyzer:
    """Analyze clusters and generate business insights"""
    
    def __init__(self):
        self.cluster_profiles = {}
        self.business_insights = {}
        
    def analyze_clusters(self, df, labels, features):
        """Analyze each cluster's characteristics"""
        print("\n" + "="*60)
        print("CLUSTER ANALYSIS")
        print("="*60)
        
        df['cluster'] = labels
        
        n_clusters = len(np.unique(labels))
        
        # Analyze each cluster
        for cluster_id in range(n_clusters):
            cluster_data = df[df['cluster'] == cluster_id]
            
            profile = {
                'size': len(cluster_data),
                'percentage': len(cluster_data) / len(df) * 100,
                'avg_age': cluster_data['age'].mean(),
                'avg_income': cluster_data['income'].mean(),
                'avg_spending_score': cluster_data['spending_score'].mean(),
                'avg_num_purchases': cluster_data['num_purchases'].mean(),
                'avg_total_spent': cluster_data['total_amount_spent'].mean(),
                'avg_recency': cluster_data['recency'].mean(),
                'avg_tenure': cluster_data['tenure'].mean(),
                'avg_discount_sensitivity': cluster_data['discount_sensitivity'].mean(),
                'avg_returns_rate': cluster_data['returns_rate'].mean(),
                'avg_estimated_clv': cluster_data['estimated_clv'].mean(),
                'avg_customer_value_score': cluster_data['customer_value_score'].mean(),
                'avg_engagement_score': cluster_data['engagement_score'].mean(),
                'avg_risk_score': cluster_data['risk_score'].mean(),
                'gender_distribution': cluster_data['gender'].value_counts().to_dict(),
                'channel_distribution': cluster_data['preferred_channel'].value_counts().to_dict()
            }
            
            self.cluster_profiles[cluster_id] = profile
            
            print(f"\n--- Cluster {cluster_id} ---")
            print(f"Size: {profile['size']} ({profile['percentage']:.1f}%)")
            print(f"Age: {profile['avg_age']:.1f}")
            print(f"Income: ${profile['avg_income']:,.0f}")
            print(f"Spending Score: {profile['avg_spending_score']:.1f}")
            print(f"Purchases: {profile['avg_num_purchases']:.1f}")
            print(f"Total Spent: ${profile['avg_total_spent']:,.0f}")
            print(f"CLV: ${profile['avg_estimated_clv']:,.0f}")
            print(f"Risk Score: {profile['avg_risk_score']:.3f}")
        
        return self.cluster_profiles
    
    def define_customer_types(self):
        """Define customer types based on cluster characteristics"""
        print("\n" + "="*60)
        print("CUSTOMER TYPE DEFINITION")
        print("="*60)
        
        customer_types = {}
        
        # Sort clusters by CLV and engagement
        cluster_metrics = []
        for cluster_id, profile in self.cluster_profiles.items():
            cluster_metrics.append({
                'cluster': cluster_id,
                'clv': profile['avg_estimated_clv'],
                'spending': profile['avg_total_spent'],
                'frequency': profile['avg_num_purchases'],
                'recency': profile['avg_recency'],
                'risk': profile['avg_risk_score'],
                'engagement': profile['avg_engagement_score'],
                'value_score': profile['avg_customer_value_score']
            })
        
        metrics_df = pd.DataFrame(cluster_metrics)
        
        # Create a composite score for unique ranking
        # Normalize each metric to 0-1 scale
        metrics_df['clv_norm'] = (metrics_df['clv'] - metrics_df['clv'].min()) / (metrics_df['clv'].max() - metrics_df['clv'].min() + 1e-10)
        metrics_df['frequency_norm'] = (metrics_df['frequency'] - metrics_df['frequency'].min()) / (metrics_df['frequency'].max() - metrics_df['frequency'].min() + 1e-10)
        metrics_df['recency_norm'] = (metrics_df['recency'].max() - metrics_df['recency']) / (metrics_df['recency'].max() - metrics_df['recency'].min() + 1e-10)  # Higher is better (more recent)
        metrics_df['risk_norm'] = (metrics_df['risk'].max() - metrics_df['risk']) / (metrics_df['risk'].max() - metrics_df['risk'].min() + 1e-10)  # Lower is better
        
        # Composite score: weighted combination of key metrics
        metrics_df['composite_score'] = (
            metrics_df['clv_norm'] * 0.35 +      # CLV is most important
            metrics_df['frequency_norm'] * 0.25 +  # Frequency matters
            metrics_df['recency_norm'] * 0.25 +    # Recency (recent = better)
            metrics_df['risk_norm'] * 0.15         # Lower risk is better
        )
        
        # Rank clusters by composite score (higher = better)
        metrics_df['rank'] = metrics_df['composite_score'].rank(ascending=False)
        
        n_clusters = len(metrics_df)
        
        # Define customer types based on unique rank positions
        # This ensures each cluster gets a unique customer type
        for _, row in metrics_df.iterrows():
            cluster_id = int(row['cluster'])
            rank = int(row['rank'])
            
            # Assign unique customer type based on rank position
            if rank == 1:
                customer_type = "Premium Loyalists"
                description = "Top-tier high-value customers with excellent engagement"
                strategy = "VIP treatment, exclusive offers, early access, dedicated support"
                priority = 'High'
            elif rank == 2:
                customer_type = "Loyal Enthusiasts"
                description = "Highly engaged customers with strong loyalty"
                strategy = "Loyalty rewards, personalized recommendations, brand ambassadors"
                priority = 'High'
            elif rank == 3:
                customer_type = "Valued Regulars"
                description = "Consistent customers with reliable purchase patterns"
                strategy = "Retention programs, incremental upgrades, satisfaction surveys"
                priority = 'Medium'
            elif rank == 4:
                customer_type = "Occasional Buyers"
                description = "Infrequent purchasers with moderate engagement"
                strategy = "Re-engagement campaigns, seasonal promotions, win-back offers"
                priority = 'Medium'
            else:  # rank 5 and below
                customer_type = "At-Risk Churners"
                description = "Low engagement customers who may be churning"
                strategy = "Win-back campaigns, special incentives, feedback collection"
                priority = 'Low'
            
            customer_types[cluster_id] = {
                'customer_type': customer_type,
                'description': description,
                'marketing_strategy': strategy,
                'priority': priority,
                'composite_score': float(row['composite_score']),
                'rank': rank
            }
            
            print(f"\nCluster {cluster_id}: {customer_type} (Rank #{rank})")
            print(f"  Description: {description}")
            print(f"  Strategy: {strategy}")
            print(f"  Composite Score: {row['composite_score']:.3f}")
        
        self.customer_types = customer_types
        return customer_types
    
    def generate_business_insights(self, df):
        """Generate actionable business insights"""
        print("\n" + "="*60)
        print("BUSINESS INSIGHTS")
        print("="*60)
        
        insights = {}
        
        # Total revenue by cluster
        cluster_revenue = df.groupby('cluster')['total_amount_spent'].sum().sort_values(ascending=False)
        total_revenue = cluster_revenue.sum()
        
        insights['revenue_by_cluster'] = {
            cluster_id: {
                'revenue': float(revenue),
                'percentage': float(revenue / total_revenue * 100)
            }
            for cluster_id, revenue in cluster_revenue.items()
        }
        
        # Highest revenue cluster
        highest_revenue_cluster = cluster_revenue.idxmax()
        insights['highest_revenue_segment'] = {
            'cluster': int(highest_revenue_cluster),
            'revenue': float(cluster_revenue.iloc[0]),
            'customer_type': self.customer_types.get(highest_revenue_cluster, {}).get('customer_type', 'Unknown')
        }
        
        # Most frequent cluster
        cluster_frequency = df.groupby('cluster')['num_purchases'].mean().sort_values(ascending=False)
        insights['most_frequent_segment'] = {
            'cluster': int(cluster_frequency.idxmax()),
            'avg_purchases': float(cluster_frequency.iloc[0]),
            'customer_type': self.customer_types.get(cluster_frequency.idxmax(), {}).get('customer_type', 'Unknown')
        }
        
        # At-risk clusters (high recency = haven't purchased recently)
        cluster_recency = df.groupby('cluster')['recency'].mean().sort_values(ascending=False)
        at_risk_clusters = cluster_recency[cluster_recency > cluster_recency.quantile(0.75)].index.tolist()
        insights['at_risk_segments'] = {
            'clusters': [int(c) for c in at_risk_clusters],
            'avg_recency_days': float(cluster_recency.iloc[-1]),
            'customer_types': [self.customer_types.get(c, {}).get('customer_type', 'Unknown') for c in at_risk_clusters]
        }
        
        # Premium segments (high CLV)
        cluster_clv = df.groupby('cluster')['estimated_clv'].mean().sort_values(ascending=False)
        premium_clusters = cluster_clv[cluster_clv > cluster_clv.quantile(0.75)].index.tolist()
        insights['premium_segments'] = {
            'clusters': [int(c) for c in premium_clusters],
            'avg_clv': float(cluster_clv.iloc[0]),
            'customer_types': [self.customer_types.get(c, {}).get('customer_type', 'Unknown') for c in premium_clusters]
        }
        
        # Print insights
        print(f"\n📊 Revenue Analysis:")
        for cluster_id, data in insights['revenue_by_cluster'].items():
            customer_type = self.customer_types.get(cluster_id, {}).get('customer_type', 'Unknown')
            print(f"  Cluster {cluster_id} ({customer_type}): ${data['revenue']:,.0f} ({data['percentage']:.1f}%)")
        
        print(f"\n💰 Highest Revenue Segment:")
        print(f"  Cluster {insights['highest_revenue_segment']['cluster']}: {insights['highest_revenue_segment']['customer_type']}")
        print(f"  Revenue: ${insights['highest_revenue_segment']['revenue']:,.0f}")
        
        print(f"\n🛒 Most Frequent Segment:")
        print(f"  Cluster {insights['most_frequent_segment']['cluster']}: {insights['most_frequent_segment']['customer_type']}")
        print(f"  Avg Purchases: {insights['most_frequent_segment']['avg_purchases']:.1f}")
        
        print(f"\n⚠️ At-Risk Segments:")
        for cluster in insights['at_risk_segments']['clusters']:
            print(f"  Cluster {cluster}: {self.customer_types.get(cluster, {}).get('customer_type', 'Unknown')}")
        
        print(f"\n⭐ Premium Segments:")
        for cluster in insights['premium_segments']['clusters']:
            print(f"  Cluster {cluster}: {self.customer_types.get(cluster, {}).get('customer_type', 'Unknown')}")
        
        self.business_insights = insights
        return insights
    
    def generate_recommendations(self):
        """Generate detailed marketing recommendations"""
        print("\n" + "="*60)
        print("MARKETING RECOMMENDATIONS")
        print("="*60)
        
        recommendations = {}
        
        for cluster_id, customer_info in self.customer_types.items():
            customer_type = customer_info['customer_type']
            profile = self.cluster_profiles[cluster_id]
            
            rec = {
                'customer_type': customer_type,
                'segment_size': profile['size'],
                'segment_percentage': profile['percentage'],
                'avg_revenue': profile['avg_total_spent'],
                'priority': customer_info['priority'],
                'marketing_tactics': [],
                'personalized_offers': [],
                'retention_strategy': []
            }
            
            if customer_type == "Premium Loyalists":
                rec['marketing_tactics'] = [
                    "VIP loyalty program with exclusive benefits",
                    "Early access to new products and sales",
                    "Personalized thank-you notes and gifts",
                    "Dedicated customer service line",
                    "Exclusive members-only events"
                ]
                rec['personalized_offers'] = [
                    "Premium product bundles at exclusive prices",
                    "Free expedited shipping on all orders",
                    "Bonus points on every purchase",
                    "Anniversary special rewards"
                ]
                rec['retention_strategy'] = [
                    "Monitor satisfaction closely with surveys",
                    "Offer customization options",
                    "Create community ambassador program"
                ]
                
            elif customer_type == "Recent High-Spenders":
                rec['marketing_tactics'] = [
                    "Welcome back campaigns",
                    "Product recommendations based on past purchases",
                    "Loyalty program enrollment",
                    "Social media retargeting"
                ]
                rec['personalized_offers'] = [
                    "10% off next purchase",
                    "Free gift with purchase over threshold",
                    "Referral bonus program"
                ]
                rec['retention_strategy'] = [
                    "Send personalized product updates",
                    "Invite to loyalty program",
                    "Follow-up satisfaction survey"
                ]
                
            elif customer_type == "Frequent Low-Spenders":
                rec['marketing_tactics'] = [
                    "Upselling and cross-selling campaigns",
                    "Bundle deals and value packs",
                    "Volume-based discounts",
                    " loyalty tier progression rewards"
                ]
                rec['personalized_offers'] = [
                    "Spend $X get $Y off next tier",
                    "Bundle recommendations",
                    "Free shipping threshold reduction"
                ]
                rec['retention_strategy'] = [
                    "Educate on premium product benefits",
                    "Show value calculation for upgrades"
                ]
                
            elif customer_type == "At-Risk Churners":
                rec['marketing_tactics'] = [
                    "Win-back email campaigns",
                    "Special comeback discounts",
                    "Survey to understand concerns",
                    "Re-engagement ads"
                ]
                rec['personalized_offers'] = [
                    "25% off comeback offer",
                    "Free return shipping",
                    "Extended loyalty points"
                ]
                rec['retention_strategy'] = [
                    "Personal outreach from customer service",
                    "Address specific pain points",
                    "Offer satisfaction guarantee"
                ]
                
            elif customer_type == "High-Risk Customers":
                rec['marketing_tactics'] = [
                    "Proactive customer service outreach",
                    "Satisfaction surveys",
                    "Return policy education",
                    "Quality assurance communication"
                ]
                rec['personalized_offers'] = [
                    "Exchange rather than return",
                    "Store credit with bonus",
                    "Product replacement offers"
                ]
                rec['retention_strategy'] = [
                    "Root cause analysis of issues",
                    "Personalized apology if needed",
                    "Monitor closely for feedback"
                ]
                
            elif customer_type == "Budget Shoppers":
                rec['marketing_tactics'] = [
                    "Value-focused messaging",
                    "Clearance and sale notifications",
                    "Budget-friendly product bundles",
                    "Email alerts for deals"
                ]
                rec['personalized_offers'] = [
                    "Student/senior discounts",
                    "Clearance item recommendations",
                    "First-time buyer offers"
                ]
                rec['retention_strategy'] = [
                    "Build relationship over time",
                    "Gradual introduction to premium products"
                ]
                
            else:  # Moderate Shoppers
                rec['marketing_tactics'] = [
                    "Nurture campaigns with valuable content",
                    "Product discovery recommendations",
                    "Seasonal promotions"
                ]
                rec['personalized_offers'] = [
                    "15% off next purchase",
                    "Free shipping over $50"
                ]
                rec['retention_strategy'] = [
                    "Engagement through content marketing",
                    "Gradual loyalty program enrollment"
                ]
            
            recommendations[cluster_id] = rec
            
            print(f"\n🎯 Cluster {cluster_id}: {customer_type}")
            print(f"   Size: {profile['size']} customers ({profile['percentage']:.1f}%)")
            print(f"   Priority: {customer_info['priority']}")
            print(f"   Marketing Tactics:")
            for tactic in rec['marketing_tactics'][:3]:
                print(f"     - {tactic}")
        
        self.recommendations = recommendations
        return recommendations
    
    def create_summary_report(self):
        """Create a summary report of all findings"""
        report = {
            'cluster_profiles': self.cluster_profiles,
            'customer_types': self.customer_types,
            'business_insights': self.business_insights,
            'recommendations': self.recommendations
        }
        return report


if __name__ == "__main__":
    # Test cluster analysis
    from data_preprocessing import DataPreprocessor
    from clustering import ClusterAnalyzer as MLClusterAnalyzer
    
    # Load and preprocess data
    preprocessor = DataPreprocessor()
    df, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
    
    # Run clustering
    ml_analyzer = MLClusterAnalyzer()
    labels = ml_analyzer.fit_final_model(X_scaled, algorithm='kmeans', n_clusters=5)
    
    # Analyze clusters
    analyzer = ClusterAnalyzer()
    analyzer.analyze_clusters(df, labels, features)
    analyzer.define_customer_types()
    analyzer.generate_business_insights(df)
    analyzer.generate_recommendations()
    
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE")
    print("="*60)
