"""
Main Entry Point for Customer Segmentation Project
Runs the complete ML pipeline and serves the frontend
"""

import os
import sys

# Ensure project directories exist
os.makedirs('data/raw', exist_ok=True)
os.makedirs('data/processed', exist_ok=True)
os.makedirs('results', exist_ok=True)
os.makedirs('reports', exist_ok=True)


def main():
    """Main function to run the customer segmentation pipeline"""
    print("=" * 70)
    print("AI-Driven Customer Intelligence System")
    print("Advanced Customer Segmentation Using Unsupervised Learning")
    print("=" * 70)
    
    # Import modules
    from src.data_generator import generate_customer_data, add_rfm_features
    from src.data_preprocessing import DataPreprocessor
    from src.clustering import ClusterAnalyzer as MLClusterAnalyzer
    from src.cluster_analysis import ClusterAnalyzer as BizClusterAnalyzer
    from src.visualization import Visualizer
    
    # Step 1: Generate Data
    print("\n[Step 1] Generating customer data...")
    print("-" * 50)
    df = generate_customer_data(n_customers=6000, random_seed=42)
    df = add_rfm_features(df)
    
    # Save raw data
    df.to_csv('data/raw/customer_data.csv', index=False)
    print(f"Generated {len(df)} customer records")
    print(f"Features: {len(df.columns)}")
    
    # Step 2: Preprocess Data
    print("\n[Step 2] Preprocessing data...")
    print("-" * 50)
    preprocessor = DataPreprocessor()
    df_processed, X_scaled, features = preprocessor.preprocess_pipeline('data/raw/customer_data.csv')
    
    # Save processed data
    df_processed.to_csv('data/processed/customer_data_processed.csv', index=False)
    print(f"Processed data saved to data/processed/")
    
    # Step 3: Run Clustering
    print("\n[Step 3] Running Clustering Algorithms...")
    print("-" * 50)
    ml_analyzer = MLClusterAnalyzer()
    
    # Compare algorithms
    comparison_results = ml_analyzer.compare_algorithms(X_scaled)
    
    # Fit final model (K-Means with 5 clusters)
    labels = ml_analyzer.fit_final_model(X_scaled, algorithm='kmeans', n_clusters=5)
    
    # Add cluster labels to data
    df_processed['cluster'] = labels
    
    # Calculate metrics
    from sklearn.metrics import silhouette_score, davies_bouldin_score
    silhouette = silhouette_score(X_scaled, labels)
    davies = davies_bouldin_score(X_scaled, labels)
    
    print(f"\n[Results] Final Model Metrics:")
    print(f"  - Silhouette Score: {silhouette:.4f}")
    print(f"  - Davies-Bouldin Index: {davies:.4f}")
    print(f"  - Number of Clusters: 5")
    
    # Step 4: Cluster Analysis
    print("\n[Step 4] Analyzing Clusters...")
    print("-" * 50)
    biz_analyzer = BizClusterAnalyzer()
    cluster_profiles = biz_analyzer.analyze_clusters(df_processed, labels, features)
    customer_types = biz_analyzer.define_customer_types()
    business_insights = biz_analyzer.generate_business_insights(df_processed)
    recommendations = biz_analyzer.generate_recommendations()
    
    # Step 5: Generate Visualizations
    print("\n[Step 5] Generating Visualizations...")
    print("-" * 50)
    viz = Visualizer(output_dir='results')
    viz.generate_all_visualizations(df_processed, X_scaled, labels, cluster_profiles)
    
    # Print Summary
    print("\n" + "=" * 70)
    print("ANALYSIS COMPLETE - SUMMARY")
    print("=" * 70)
    
    print(f"\n📊 Dataset:")
    print(f"   - Total Customers: {len(df)}")
    print(f"   - Features Used: {len(features)}")
    
    print(f"\n🎯 Clustering Results:")
    print(f"   - Algorithm: K-Means")
    print(f"   - Clusters: 5")
    print(f"   - Silhouette Score: {silhouette:.4f}")
    print(f"   - Davies-Bouldin Index: {davies:.4f}")
    
    print(f"\n👥 Customer Segments:")
    for cluster_id, profile in cluster_profiles.items():
        cust_type = customer_types.get(cluster_id, {}).get('customer_type', 'Unknown')
        print(f"   Cluster {cluster_id} ({cust_type}): {profile['size']} customers ({profile['percentage']:.1f}%)")
    
    print(f"\n💰 Business Insights:")
    print(f"   - Highest Revenue: Cluster {business_insights['highest_revenue_segment']['cluster']}")
    print(f"   - At-Risk Segments: {business_insights['at_risk_segments']['clusters']}")
    print(f"   - Premium Segments: {business_insights['premium_segments']['clusters']}")
    
    print(f"\n📁 Output Files:")
    print(f"   - Raw Data: data/raw/customer_data.csv")
    print(f"   - Processed Data: data/processed/customer_data_processed.csv")
    print(f"   - Visualizations: results/*.png")
    
    print("\n" + "=" * 70)
    print("To start the web interface, run:")
    print("   python src/api.py")
    print("   Then open http://localhost:5000 in your browser")
    print("=" * 70)
    
    return df_processed, labels, cluster_profiles, customer_types, business_insights


if __name__ == "__main__":
    main()
