@echo off
REM Customer Segmentation Project - Run Script

echo ======================================
echo AI-Driven Customer Intelligence System
echo ======================================
echo.

echo Installing dependencies...
pip install -r requirements.txt

echo.
echo Running analysis...
python main.py

echo.
echo ======================================
echo Analysis Complete!
echo.
echo To start the web interface:
echo   cd src
echo   python api.py
echo.
echo Then open http://localhost:5000 in your browser
echo ======================================
pause
