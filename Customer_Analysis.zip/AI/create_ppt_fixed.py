"""
Script to generate PowerPoint presentation for Customer Segmentation Project
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

# Create presentation
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Define colors
TITLE_COLOR = RGBColor(0, 51, 102)
ACCENT_COLOR = RGBColor(0, 102, 204)
TEXT_COLOR = RGBColor(51, 51, 51)

def set_slide_background(slide):
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(255, 255, 255)

def add_title_slide(prs, title, subtitle, presenter, usn, guide, institution):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2), Inches(12.333), Inches(1.5))
    title_frame = title_box.text_frame
    title_frame.word_wrap = True
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(44)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(3.5), Inches(12.333), Inches(0.8))
    sub_frame = sub_box.text_frame
    p = sub_frame.paragraphs[0]
    p.text = subtitle
    p.font.size = Pt(24)
    p.font.color.rgb = ACCENT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    info_box = slide.shapes.add_textbox(Inches(0.5), Inches(4.5), Inches(12.333), Inches(2.5))
    info_frame = info_box.text_frame
    
    p = info_frame.paragraphs[0]
    p.text = f"Presented By: {presenter}"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"USN: {usn}"
    p.font.size = Pt(16)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"Under the guidance of: {guide}"
    p.font.size = Pt(16)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"\n{institution}"
    p.font.size = Pt(14)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER

def add_content_slide(prs, title, bullets):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    content_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(12.333), Inches(6))
    content_frame = content_box.text_frame
    
    for i, bullet in enumerate(bullets):
        if i == 0:
            p = content_frame.paragraphs[0]
        else:
            p = content_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(20)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(12)

def add_two_column_slide(prs, title, left_title, left_bullets, right_title, right_bullets):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    left_title_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(5.5), Inches(0.5))
    left_title_frame = left_title_box.text_frame
    p = left_title_frame.paragraphs[0]
    p.text = left_title
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    left_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.7), Inches(5.5), Inches(5))
    left_frame = left_box.text_frame
    
    for i, bullet in enumerate(left_bullets):
        if i == 0:
            p = left_frame.paragraphs[0]
        else:
            p = left_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(16)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(8)
    
    right_title_box = slide.shapes.add_textbox(Inches(7), Inches(1.2), Inches(5.5), Inches(0.5))
    right_title_frame = right_title_box.text_frame
    p = right_title_frame.paragraphs[0]
    p.text = right_title
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    right_box = slide.shapes.add_textbox(Inches(7), Inches(1.7), Inches(5.5), Inches(5))
    right_frame = right_box.text_frame
    
    for i, bullet in enumerate(right_bullets):
        if i == 0:
            p = right_frame.paragraphs[0]
        else:
            p = right_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(16)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(8)

def add_architecture_slide(prs, title):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    arch_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(12.333), Inches(5.5))
    arch_frame = arch_box.text_frame
    
    p = arch_frame.paragraphs[0]
    p.text = "PRESENTATION LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Web Interface (HTML/CSS/JS)"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Chart.js for Interactive Visualizations"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "          ↓"
    p.font.size = Pt(18)
    p.alignment = PP_ALIGN.CENTER
    
    p = arch_frame.add_paragraph()
    p.text = "APPLICATION LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Flask Web Server (API)"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Business Logic Layer"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "          ↓"
    p.font.size = Pt(18)
    p.alignment = PP_ALIGN.CENTER
    
    p = arch_frame.add_paragraph()
    p.text = "DATA LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Raw Data | Processed Data | Results"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR

def add_thankyou_slide(prs, title, contact_info):
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2.5), Inches(12.333), Inches(1.5))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(56)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    info_box = slide.shapes.add_textbox(Inches(0.5), Inches(4.5), Inches(12.333), Inches(2))
    info_frame = info_box.text_frame
    
    p = info_frame.paragraphs[0]
    p.text = contact_info
    p.font.size = Pt(20)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER

# CREATE SLIDES

add_title_slide(prs, "AI-Driven Customer Segmentation System",
    "Advanced Customer Segmentation Using Unsupervised Learning",
    "Ramanagouda S Patil", "01FE23BCA207", "Prof. Anusha Hiremath",
    "KLE TECHNOLOGICAL UNIVERSITY\nB. V. Bhoomaraddi Campus, Hubballi-580031")

add_content_slide(prs, "Project Overview", [
    "AI-Driven Customer Segmentation System using Unsupervised ML",
    "Analyzes customer data and groups into meaningful segments",
    "Discovers hidden patterns and behavioral clusters",
    "Generates actionable business insights",
    "Provides user-friendly web interface",
    "Key: 6000+ records, 20+ features, Multiple algorithms"
])

add_content_slide(prs, "Problem Statement", [
    "Companies have data but don't know:",
    "• Who are the most valuable customers",
    "• Which customers are likely to churn",
    "• Which group spends the most",
    "Challenge: Manual analysis is inefficient",
    "Solution: Unsupervised learning for pattern discovery"
])

add_content_slide(prs, "Objectives", [
    "1. Build intelligent customer grouping system using unsupervised learning",
    "2. Process large volumes to identify spending habits and loyalty",
    "3. Implement multiple clustering algorithms (K-Means, Hierarchical, DBSCAN, GMM)",
    "4. Provide insights: high-value, at-risk, churn predictions",
    "5. Provide graphical representations for easy understanding",
    "6. Offer web-based interface using Flask and Chart.js",
    "7. Support data-driven business growth"
])

add_content_slide(prs, "Scope", [
    "Customer Data Processing: Collection, cleaning, transformation",
    "Automated Segmentation: K-Means, Hierarchical, DBSCAN, GMM",
    "Behavioral & Revenue Analysis: High-value, at-risk, premium segments",
    "Advanced Visualization: Cluster charts, heatmaps, PCA, t-SNE",
    "Business Insight Generation: Marketing strategies",
    "Web Interface: Flask with Chart.js",
    "Performance Evaluation: Silhouette, Davies-Bouldin, Calinski-Harabasz",
    "Scalability: 6000+ customer records"
])

add_content_slide(prs, "Existing System Limitations", [
    "Manual Data Analysis - Time-consuming, error-prone",
    "Limited Analytical Techniques - No advanced ML",
    "Single Algorithm Approach - No comparison",
    "Static Reporting - No real-time insights",
    "Poor Visualization - Hard to interpret",
    "Lack of Automation - Manual effort required",
    "Scalability Issues - Performance bottlenecks",
    "No Integrated Web Interface"
])

add_content_slide(prs, "Proposed System Features", [
    "Multiple Clustering: K-Means, Hierarchical, DBSCAN, GMM",
    "Automated Segmentation based on behavior",
    "Real-Time Data Processing",
    "Advanced Interactive Visualizations",
    "Business Insight Generation",
    "Web Interface with Flask and Chart.js",
    "Performance Evaluation using metrics",
    "Algorithm Comparison for best model selection",
    "Dimensionality Reduction with PCA and t-SNE"
])

add_architecture_slide(prs, "System Architecture (Three-Tier)")

add_content_slide(prs, "Methodology", [
    "Step 1: Data Collection - 6000+ records, 20+ features",
    "Step 2: Data Cleaning - Missing value imputation",
    "Step 3: Outlier Detection - IQR method",
    "Step 4: Feature Scaling - StandardScaler",
    "Step 5: Feature Engineering - RFM, CLV, engagement score",
    "Step 6: Dimensionality Reduction - PCA, t-SNE",
    "Step 7: Clustering - K-Means, Hierarchical, DBSCAN, GMM",
    "Step 8: Algorithm Comparison - Evaluation metrics",
    "Step 9: Cluster Analysis - Segment identification",
    "Step 10: Business Insights - Marketing recommendations",
    "Step 11: Visualization - Charts and graphs",
    "Step 12: Web Deployment - Flask UI"
])

add_content_slide(prs, "Dataset Description", [
    "Dataset Size: 6,000+ customer records",
    "Features (20+):",
    "• Demographics: Age, Gender, Income",
    "• Behavioral: Spending Score, Purchase History",
    "• Transaction: Recency, Total Amount Spent",
    "Derived Features:",
    "• RFM (Recency, Frequency, Monetary)",
    "• Customer Lifetime Value (CLV)",
    "• Engagement Score, Risk Score",
    "• Purchase Velocity, Tenure"
])

add_content_slide(prs, "Data Preprocessing", [
    "1. Missing Value Imputation",
    "   • Median for numerical, Mode for categorical",
    "2. Outlier Detection - IQR method",
    "3. Feature Scaling - StandardScaler",
    "4. Categorical Encoding - LabelEncoder"
])

add_content_slide(prs, "Feature Engineering", [
    "Key Derived Features:",
    "1. RFM Features",
    "   • Recency, Frequency, Monetary",
    "2. Customer Value Score (0-100)",
    "3. Engagement Score",
    "4. Risk Score - Churn probability",
    "5. Purchase Velocity",
    "6. Average Order Value"
])

add_content_slide(prs, "Clustering Algorithms", [
    "1. K-Means Clustering",
    "   • Most widely used, efficient for large datasets",
    "   • Uses elbow method and silhouette score",
    "2. Hierarchical Clustering",
    "   • Agglomerative with Ward linkage",
    "   • Creates dendrogram",
    "3. DBSCAN",
    "   • Density-based, identifies outliers",
    "4. Gaussian Mixture Model (GMM)",
    "   • Probabilistic, soft clustering"
])

add_content_slide(prs, "Algorithm Comparison", [
    "Evaluation Metrics:",
    "• Silhouette Score: Higher is better",
    "• Davies-Bouldin Index: Lower is better",
    "• Calinski-Harabasz: Higher is better",
    "• BIC/AIC: Lower is better (for GMM)",
    "",
    "Result: K-Means with 5 clusters selected",
    "• Silhouette Score > 0.3",
    "• Davies-Bouldin Index < 1.5"
])

add_content_slide(prs, "Clustering Results", [
    "Final Model:",
    "• Algorithm: K-Means",
    "• Clusters: 5",
    "• Silhouette Score: > 0.3",
    "• Davies-Bouldin Index: < 1.5",
    "",
    "Cluster Distribution:",
    "• Each cluster = distinct customer behavior",
    "• Clear separation between segments"
])

add_content_slide(prs, "Customer Segments", [
    "1. PREMIUM LOYALISTS",
    "   • Top-tier high-value customers",
    "2. LOYAL ENTHUSIASTS",
    "   • Highly engaged, strong loyalty",
    "3. VALUED REGULARS",
    "   • Consistent, reliable patterns",
    "4. OCCASIONAL BUYERS",
    "   • Infrequent, moderate engagement",
    "5. AT-RISK CHURNERS",
    "   • Low engagement, may churn"
])

add_content_slide(prs, "Business Insights", [
    "1. Revenue Analysis",
    "   • Distribution by cluster",
    "   • Highest revenue segment",
    "2. Customer Value",
    "   • Premium segments (highest CLV)",
    "   • At-risk segments",
    "3. Risk Assessment",
    "   • Churn probability indicators",
    "4. Engagement Patterns",
    "   • Purchase frequency, channel preferences"
])

add_content_slide(prs, "Marketing Recommendations", [
    "PREMIUM LOYALISTS:",
    "• VIP loyalty program, Early access, Gifts",
    "",
    "AT-RISK CHURNERS:",
    "• Win-back campaigns, Special discounts",
    "",
    "FREQUENT LOW-SPENDERS:",
    "• Upselling, Bundle deals, Volume discounts",
    "",
    "OCCASIONAL BUYERS:",
    "• Re-engagement, Seasonal promotions"
])

add_content_slide(prs, "Visualizations", [
    "1. Cluster Distribution Charts",
    "2. Revenue Comparison Graphs",
    "3. Correlation Heatmap",
    "4. PCA 2D Visualization",
    "5. t-SNE Visualization",
    "6. Demographic Analysis",
    "7. Cluster Profiles"
])

add_content_slide(prs, "Web Interface", [
    "Features:",
    "• Bootstrap responsive design",
    "• Interactive Chart.js charts",
    "• Real-time clustering results",
    "• Segment profiles",
    "• Marketing recommendations",
    "",
    "Access: python src/api.py",
    "URL: http://localhost:5000",
    "",
    "Tech: Flask, HTML/CSS/JS, Chart.js"
])

add_content_slide(prs, "Technology Stack", [
    "Language: Python 3.8+",
    "Data: Pandas, NumPy",
    "ML: Scikit-learn, SciPy",
    "Viz: Matplotlib, Seaborn, Plotly",
    "Web: Flask, Chart.js, Bootstrap",
    "Other: Excel/Word - Documentation"
])

add_two_column_slide(prs, "Requirements",
    "Hardware (Server)", [
        "Processor: Intel Core i5/i7",
        "RAM: 8 GB min (16 GB rec.)",
        "Storage: 500 GB SSD min",
        "Network: 100 Mbps",
        "",
        "Hardware (Client)",
        "• Intel i3 or equivalent",
        "• RAM: 4 GB min",
        "• Display: 1024x768"
    ],
    "Software (Server)", [
        "OS: Windows 10/11, macOS, Linux",
        "Python 3.8+",
        "Flask & required libraries",
        "",
        "Software (Client)",
        "• OS: Windows 10+, macOS, Linux",
        "• Browser: Chrome, Firefox, Edge"
    ]
)

add_content_slide(prs, "Phase-wise Plan", [
    "Phase 1: Requirement Analysis",
    "Phase 2: System Design",
    "Phase 3: Data Collection & Preprocessing",
    "Phase 4: Feature Engineering",
    "Phase 5: Algorithm Implementation",
    "Phase 6: Testing & Validation",
    "Phase 7: Web Interface Development",
    "Phase 8: Deployment & Documentation"
])

add_content_slide(prs, "Conclusion", [
    "System Successfully:",
    "• Implements multiple unsupervised algorithms",
    "• Processes 6000+ records with 20+ features",
    "• Identifies 5 distinct customer segments",
    "• Generates actionable business insights",
    "• Provides interactive web interface",
    "• Achieves meaningful clustering",
    "",
    "Benefits:",
    "• Improved customer understanding",
    "• Targeted marketing",
    "• Better retention",
    "• Data-driven decisions"
])

add_content_slide(prs, "References", [
    "1. Han, Pei, Kamber - Data Mining (Morgan Kaufmann)",
    "2. Tan, Steinbach, Kumar - Intro to Data Mining (Pearson)",
    "3. Aggarwal - Data Mining: The Textbook (Springer)",
    "4. Pedregosa et al. - Scikit-learn (JMLR)",
    "5. McKinney - Pandas (Python Science Conference)",
    "6. scikit-learn Documentation",
    "7. Flask Documentation",
    "8. Chart.js Documentation"
])

add_thankyou_slide(prs, "Thank You",
    "Questions?\n\nContact:\nRamanagouda S Patil\nUSN: 01FE23BCA207\nKLE Technological University\n\nGuided by: Prof. Anusha Hiremath")

# Save presentation
output_path = "customer_segmentation_presentation.pptx"
prs.save(output_path)
print(f"Presentation saved: {output_path}")
print(f"Total slides: {len(prs.slides)}")
