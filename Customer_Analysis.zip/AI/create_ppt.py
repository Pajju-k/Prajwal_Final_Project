"""
Script to generate PowerPoint presentation for Customer Segmentation Project
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
import os

# Create presentation
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Define colors
TITLE_COLOR = RGBColor(0, 51, 102)  # Dark blue
ACCENT_COLOR = RGBColor(0, 102, 204)  # Blue
TEXT_COLOR = RGBColor(51, 51, 51)  # Dark gray

def set_slide_background(slide):
    """Set slide background color"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(255, 255, 255)

def add_title_slide(prs, title, subtitle, presenter, usn, guide, institution):
    """Add title slide"""
    slide_layout = prs.slide_layouts[6]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    # Main title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2), Inches(12.333), Inches(1.5))
    title_frame = title_box.text_frame
    title_frame.word_wrap = True
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(44)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    # Subtitle
    sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(3.5), Inches(12.333), Inches(0.8))
    sub_frame = sub_box.text_frame
    p = sub_frame.paragraphs[0]
    p.text = subtitle
    p.font.size = Pt(24)
    p.font.color.rgb = ACCENT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    # Presenter info
    y_pos = 4.5
    info_box = slide.shapes.add_textbox(Inches(0.5), Inches(y_pos), Inches(12.333), Inches(2.5))
    info_frame = info_box.text_frame
    
    p = info_frame.paragraphs[0]
    p.text = f"Presented By: {presenter}"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"USN: {usn}"
    p.font.size = Pt(16)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"Under the guidance of: {guide}"
    p.font.size = Pt(16)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    p = info_frame.add_paragraph()
    p.text = f"\n{institution}"
    p.font.size = Pt(14)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER

def add_content_slide(prs, title, bullets):
    """Add content slide with bullets"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    # Content
    content_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(12.333), Inches(6))
    content_frame = content_box.text_frame
    
    for i, bullet in enumerate(bullets):
        if i == 0:
            p = content_frame.paragraphs[0]
        else:
            p = content_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(20)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(12)

def add_two_column_slide(prs, title, left_title, left_bullets, right_title, right_bullets):
    """Add two column slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    # Left column title
    left_title_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(5.5), Inches(0.5))
    left_title_frame = left_title_box.text_frame
    p = left_title_frame.paragraphs[0]
    p.text = left_title
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    # Left column content
    left_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.7), Inches(5.5), Inches(5))
    left_frame = left_box.text_frame
    
    for i, bullet in enumerate(left_bullets):
        if i == 0:
            p = left_frame.paragraphs[0]
        else:
    p = left_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(16)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(8)
    
    # Right column title
    right_title_box = slide.shapes.add_textbox(Inches(7), Inches(1.2), Inches(5.5), Inches(0.5))
    right_title_frame = right_title_box.text_frame
    p = right_title_frame.paragraphs[0]
    p.text = right_title
    p.font.size = Pt(24)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    # Right column content
    right_box = slide.shapes.add_textbox(Inches(7), Inches(1.7), Inches(5.5), Inches(5))
    right_frame = right_box.text_frame
    
    for i, bullet in enumerate(right_bullets):
        if i == 0:
            p = right_frame.paragraphs[0]
        else:
            p = right_frame.add_paragraph()
        p.text = "• " + bullet
        p.font.size = Pt(16)
        p.font.color.rgb = TEXT_COLOR
        p.space_after = Pt(8)

def add_architecture_slide(prs, title):
    """Add system architecture slide with text diagram"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.3), Inches(12.333), Inches(0.8))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    
    # Architecture content
    arch_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.2), Inches(12.333), Inches(5.5))
    arch_frame = arch_box.text_frame
    
    # Presentation Layer
    p = arch_frame.paragraphs[0]
    p.text = "PRESENTATION LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Web Interface (HTML/CSS/JS)"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Chart.js for Interactive Visualizations"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Bootstrap for Responsive Design"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "          ↓"
    p.font.size = Pt(18)
    p.alignment = PP_ALIGN.CENTER
    
    # Application Layer
    p = arch_frame.add_paragraph()
    p.text = "APPLICATION LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Flask Web Server (API)"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Business Logic Layer (ClusterAnalyzer, DataPreprocessor, Visualizer)"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "          ↓"
    p.font.size = Pt(18)
    p.alignment = PP_ALIGN.CENTER
    
    # Data Layer
    p = arch_frame.add_paragraph()
    p.text = "DATA LAYER"
    p.font.size = Pt(22)
    p.font.bold = True
    p.font.color.rgb = ACCENT_COLOR
    
    p = arch_frame.add_paragraph()
    p.text = "• Raw Data (CSV) | Processed Data | Results/Output"
    p.font.size = Pt(18)
    p.font.color.rgb = TEXT_COLOR

def add_thankyou_slide(prs, title, contact_info):
    """Add thank you slide"""
    slide_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(slide_layout)
    set_slide_background(slide)
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(0.5), Inches(2.5), Inches(12.333), Inches(1.5))
    title_frame = title_box.text_frame
    p = title_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(56)
    p.font.bold = True
    p.font.color.rgb = TITLE_COLOR
    p.alignment = PP_ALIGN.CENTER
    
    # Contact info
    info_box = slide.shapes.add_textbox(Inches(0.5), Inches(4.5), Inches(12.333), Inches(2))
    info_frame = info_box.text_frame
    
    p = info_frame.paragraphs[0]
    p.text = contact_info
    p.font.size = Pt(20)
    p.font.color.rgb = TEXT_COLOR
    p.alignment = PP_ALIGN.CENTER

# ============================================================
# CREATE SLIDES
# ============================================================

# Slide 1: Title Slide
add_title_slide(prs, 
    "AI-Driven Customer Segmentation System",
    "Advanced Customer Segmentation Using Unsupervised Learning",
    "Ramanagouda S Patil",
    "01FE23BCA207",
    "Prof. Anusha Hiremath",
    "KLE TECHNOLOGICAL UNIVERSITY\nB. V.i Campus, Hubballi-580 Bhoomaradd031")

# Slide 2: Project Overview
add_content_slide(prs, "Project Overview", [
    "AI-Driven Customer Segmentation System using Unsupervised Machine Learning",
    "Analyzes customer data and groups customers into meaningful segments",
    "Processes raw customer data to discover hidden patterns and behavioral clusters",
    "Generates actionable business insights for marketing and strategic decisions",
    "Provides a user-friendly web interface for visualization and analysis",
    "Key Highlights: 6000+ customer records, 20+ features, Multiple algorithms"
])

# Slide 3: Problem Statement
add_content_slide(prs, "Problem Statement", [
    "A company has collected large volumes of customer data but doesn't know:",
    "• Who their most valuable customers are",
    "• Which customers are likely to churn",
    "• Which customer group spends the most",
    "• Which group responds better to offers",
    "Challenge: Manual analysis of such data is inefficient and inaccurate",
    "Solution: Unsupervised learning to identify hidden patterns automatically"
])

# Slide 4: Objectives
add_content_slide(prs, "Objectives", [
    "1. Build an intelligent system for automatic customer grouping using unsupervised learning",
    "2. Process large volumes of customer data to identify spending habits, purchase frequency, and loyalty",
    "3. Implement multiple clustering algorithms (K-Means, Hierarchical, DBSCAN, GMM)",
    "4. Interpret results to provide insights: high-value customers, at-risk customers, churn predictions",
    "5. Provide graphical representations for easy understanding",
    "6. Offer web-based interface using Flask and Chart.js",
    "7. Support business growth through analytical results"
])

# Slide 5: Scope
add_content_slide(prs, "Scope", [
    "Customer Data Processing: Collection, cleaning, transformation, preprocessing",
    "Automated Customer Segmentation: Using K-Means, Hierarchical, DBSCAN, GMM",
    "Behavioral and Revenue Analysis: High-value, at-risk, premium, budget segments",
    "Advanced Data Visualization: Cluster charts, heatmaps, PCA plots, t-SNE",
    "Business Insight Generation: Marketing strategies and customer retention",
    "Web-Based Interface: Flask application with Chart.js",
    "Algorithm Performance Evaluation: Silhouette, Davies-Bouldin, Calinski-Harabasz, BIC, AIC",
    "Scalability: Supports 6000+ customer records efficiently"
])

# Slide 6: Existing System Limitations
add_content_slide(prs, "Existing System Limitations", [
    "Manual Data Analysis - Time-consuming and prone to human errors",
    "Limited Analytical Techniques - Without advanced ML algorithms",
    "Single Algorithm Approach - No comparison of multiple algorithms",
    "Static Reporting - No real-time insights",
    "Poor Visualization Capabilities - Hard to interpret complex patterns",
    "Lack of Automation - Requires continuous manual effort",
    "Scalability Issues - Performance bottlenecks with large datasets",
    "Limited Business Insights - Poor identification of customer trends",
    "No Integrated Web Interface - Not user-friendly"
])

# Slide 7: Proposed System
add_content_slide(prs, "Proposed System Features", [
    "Multiple Clustering Algorithms: K-Means, Hierarchical, DBSCAN, GMM",
    "Automated Customer Segmentation based on behavior and demographics",
    "Real-Time Data Processing for faster decision-making",
    "Advanced Data Visualization with interactive charts",
    "Business Insight Generation for targeted marketing",
    "Web-Based Interface with Flask and Chart.js",
    "Performance Evaluation using multiple metrics",
    "Algorithm Comparison to select the best model",
    "Dimensionality Reduction with PCA and t-SNE",
    "Scalable Architecture and Secure Data Handling"
])

# Slide 8: System Architecture
add_architecture_slide(prs, "System Architecture (Three-Tier)")

# Slide 9: Methodology
add_content_slide(prs, "Methodology", [
    "Step 1: Data Collection - 6000+ customer records, 20+ features",
    "Step 2: Data Cleaning - Missing value imputation (median/mode)",
    "Step 3: Outlier Detection - IQR method",
    "Step 4: Feature Scaling - StandardScaler normalization",
    "Step 5: Feature Engineering - RFM features, CLV, engagement score",
    "Step 6: Dimensionality Reduction - PCA and t-SNE",
    "Step 7: Clustering - K-Means, Hierarchical, DBSCAN, GMM",
    "Step 8: Algorithm Comparison - Silhouette, Davies-Bouldin, Calinski",
    "Step 9: Cluster Analysis - Customer segment identification",
    "Step 10: Business Insights - Marketing recommendations",
    "Step 11: Visualization - Charts and graphs",
    "Step 12: Web Deployment - Flask with interactive UI"
])

# Slide 10: Dataset Description
add_content_slide(prs, "Dataset Description", [
    "Dataset Size: 6,000+ customer records",
    "Features (20+):",
    "• Demographics: Age, Gender, Income",
    "• Behavioral: Spending Score, Purchase History, Frequency",
    "• Transaction: Recency, Total Amount Spent, Average Purchase Amount",
    "Derived Features:",
    "• RFM Features (Recency, Frequency, Monetary)",
    "• Customer Lifetime Value (CLV)",
    "• Customer Value Score, Engagement Score, Risk Score",
    "• Purchase Velocity, Average Order Value, Tenure"
])

# Slide 11: Data Preprocessing
add_content_slide(prs, "Data Preprocessing", [
    "1. Missing Value Imputation",
    "   • Median imputation for numerical features",
    "   • Mode imputation for categorical features",
    "2. Outlier Detection and Handling",
    "   • IQR (Interquartile Range) method",
    "   • Values beyond Q1-1.5*IQR or Q3+1.5*IQR are treated",
    "3. Feature Scaling",
    "   • StandardScaler for normalization",
    "   • Ensures all features contribute equally",
    "4. Categorical Encoding",
    "   • LabelEncoder for categorical variables"
])

# Slide 12: Feature Engineering
add_content_slide(prs, "Feature Engineering", [
    "Key Derived Features:",
    "1. RFM Features",
    "   • Recency: Days since last purchase",
    "   • Frequency: Number of purchases",
    "   • Monetary: Total amount spent",
    "2. Customer Value Score - Composite metric (0-100)",
    "3. Engagement Score - Customer interaction level",
    "4. Risk Score - Churn probability indicator",
    "5. Purchase Velocity - Average purchases per time period",
    "6. Average Order Value - Mean spending per transaction"
])

# Slide 13: Algorithms Used
add_content_slide(prs, "Clustering Algorithms Used", [
    "1. K-Means Clustering",
    "   • Most widely used partitioning algorithm",
    "   • Efficient for large datasets",
    "   • Uses elbow method and silhouette score",
    "2. Hierarchical Clustering",
    "   • Agglomerative with Ward linkage",
    "   • Creates dendrogram for visual hierarchy",
    "3. DBSCAN (Density-Based)",
    "   • Identifies outliers automatically",
    "   • No assumption of spherical clusters",
    "4. Gaussian Mixture Model (GMM)",
    "   • Probabilistic clustering",
    "   • Soft clustering with probability assignments"
])

# Slide 14: Algorithm Comparison
add_content_slide(prs, "Algorithm Comparison", [
    "Evaluation Metrics:",
    "• Silhouette Score: Higher is better (max 1)",
    "• Davies-Bouldin Index: Lower is better",
    "• Calinski-Harabasz Score: Higher is better",
    "• BIC/AIC: Lower is better (for GMM)",
    "",
    "Algorithm Comparison:",
    "• K-Means: 5 clusters, Silhouette > 0.3, Davies-Bouldin < 1.5",
    "• Hierarchical: Variable clusters based on dendrogram",
    "• DBSCAN: Variable clusters, identifies outliers",
    "• GMM: Variable clusters, uses BIC for selection",
    "",
    "Result: K-Means with 5 clusters selected as final model"
])

# Slide 15: Clustering Results
add_content_slide(prs, "Clustering Results", [
    "Final Model Performance:",
    "• Algorithm: K-Means",
    "• Number of Clusters: 5",
    "• Silhouette Score: > 0.3",
    "• Davies-Bouldin Index: < 1.5",
    "",
    "Cluster Distribution:",
    "• Each cluster represents distinct customer behavior",
    "• Clusters vary in size based on customer patterns",
    "• Clear separation between customer segments"
])

# Slide 16: Customer Segments Discovered
add_content_slide(prs, "Customer Segments Discovered", [
    "1. PREMIUM LOYALISTS",
    "   • Top-tier high-value customers with excellent engagement",
    "2. LOYAL ENTHUSIASTS",
    "   • Highly engaged customers with strong loyalty",
    "3. VALUED REGULARS",
    "   • Consistent customers with reliable purchase patterns",
    "4. OCCASIONAL BUYERS",
    "   • Infrequent purchasers with moderate engagement",
    "5. AT-RISK CHURNERS",
    "   • Low engagement customers who may be churning"
])

# Slide 17: Business Insights
add_content_slide(prs, "Business Insights", [
    "1. Revenue Analysis",
    "   • Total revenue distribution by cluster",
    "   • Highest revenue segment identified",
    "2. Customer Value Insights",
    "   • Premium segments with highest CLV",
    "   • At-risk segments requiring attention",
    "3. Risk Assessment",
    "   • Churn probability indicators",
    "   • Risk score analysis per segment",
    "4. Engagement Patterns",
    "   • Purchase frequency analysis",
    "   • Channel preferences, Discount sensitivity"
])

# Slide 18: Marketing Recommendations
add_content_slide(prs, "Marketing Recommendations", [
    "PREMIUM LOYALISTS:",
    "• VIP loyalty program, Early access, Personalized gifts",
    "",
    "AT-RISK CHURNERS:",
    "• Win-back campaigns, Special discounts, Proactive outreach",
    "",
    "FREQUENT LOW-SPENDERS:",
    "• Upselling campaigns, Bundle deals, Volume discounts",
    "",
    "OCCASIONAL BUYERS:",
    "• Re-engagement campaigns, Seasonal promotions"
])

# Slide 19: Visualizations
add_content_slide(prs, "Visualizations Generated", [
    "1. Cluster Distribution Charts - Size and percentage of each cluster",
    "2. Revenue Comparison Graphs - Revenue by cluster",
    "3. Correlation Heatmap - Feature correlations",
    "4. PCA 2D Visualization - Dimensionality reduction for 2D plotting",
    "5. t-SNE Visualization - Non-linear dimensionality reduction",
    "6. Demographic Analysis - Age, income, gender by cluster",
    "7. Cluster Profiles - Detailed characteristics of each segment"
])

# Slide 20: Web Interface
add_content_slide(prs, "Web Interface", [
    "Features:",
    "• Modern dashboard with Bootstrap responsive design",
    "• Interactive charts using Chart.js",
    "• Real-time clustering results display",
    "• Customer segment profiles",
    "• Marketing recommendations",
    "• Business insights visualization",
    "",
    "How to Access:",
    "• Run: python src/api.py",
    "• Open: http://localhost:5000 in browser",
    "",
    "Technologies: Flask, HTML/CSS/JS, Chart.js, Bootstrap"
])

# Slide 21: Technology Stack
add_content_slide(prs, "Technology Stack", [
    "Programming Language: Python 3.8+",
    "",
    "Data Manipulation: Pandas, NumPy",
    "",
    "Machine Learning: Scikit-learn, SciPy",
    "",
    "Visualization: Matplotlib, Seaborn, Plotly",
    "",
    "Web Development: Flask, Chart.js, Bootstrap",
    "",
    "Other: Microsoft Excel/Word - Documentation"
])

# Slide 22: Hardware & Software Requirements
add_two_column_slide(prs, "Hardware & Software Requirements",
    "Hardware (Server)",
    ["Processor: Intel Core i5/i7 or AMD Ryzen",
     "RAM: Minimum 8 GB (Recommended 16 GB)",
     "Storage: Minimum 500 GB SSD",
     "Network: 100 Mbps broadband",
     "",
     "Hardware (Client)",
     "• Processor: Intel i3 or equivalent",
     "• RAM: Minimum 4 GB",
     "• Display: 1024 × 768 resolution"],
    
    "Software (Server-Side)",
    ["OS: Windows 10/11, macOS, or Linux",
     "Python 3.8+",
     "Flask and required libraries",
     "",
     "Software (Client-Side)",
     "• OS: Windows 10+, macOS, or Linux",
     "• Browser: Chrome, Firefox, Edge, Safari"]
)

# Slide 23: Phase-wise Plan
add_content_slide(prs, "Phase-wise Implementation Plan", [
    "Phase 1: Requirement Analysis - Identify objectives and user roles",
    "Phase 2: System Design - Design architecture and data flow",
    "Phase 3: Data Collection & Preprocessing - Generate/collect data, clean",
    "Phase 4: Feature Engineering - Create RFM features and derived metrics",
    "Phase 5: Algorithm Implementation - Implement K-Means, Hierarchical, DBSCAN, GMM",
    "Phase 6: Testing & Validation - Validate using Silhouette, Davies-Bouldin",
    "Phase 7: Web Interface Development - Develop Flask backend and HTML dashboard",
    "Phase 8: Deployment & Documentation - Deploy and prepare documentation"
])

# Slide 24: Conclusion
add_content_slide(prs, "Conclusion", [
    "The AI-Driven Customer Segmentation System successfully:",
    "• Implements multiple unsupervised learning algorithms",
    "• Processes 6000+ customer records with 20+ features",
    "• Identifies 5 distinct customer segments",
    "• Generates actionable business insights",
    "• Provides interactive web interface",
    "• Achieves meaningful clustering with Silhouette Score > 0.3",
    "",
    "Benefits:",
    "• Improved customer understanding",
    "• Targeted marketing strategies",
    "• Better customer retention",
    "• Data-driven decision making"
])

# Slide 25: References
add_content_slide(prs, "References", [
    "1. Han, J., Pei, J., & Kamber, M. (2011). Data Mining: Concepts and Techniques (3rd ed.). Morgan Kaufmann.",
    "2. Tan, P. N., Steinbach, M., & Kumar, V. (2018). Introduction to Data Mining (2nd ed.). Pearson.",
    "3. Aggarwal, C. C. (2015). Data Mining: The Textbook. Springer.",
    "4. Pedregosa, F., et al. (2011). Scikit-learn: Machine learning in Python. JMLR, 12, 2825–2830.",
    "5. McKinney, W. (2010). Data structures for statistical computing in Python. Proceedings of PySci.",
    "6. scikit-learn Documentation. (2023). Clustering. https://scikit-learn.org",
    "7. Flask Documentation. (2023). https://flask.palletsprojects.com/",
    "8. Chart.js Documentation. (2023). https://www.chartjs.org/"
])

# Slide 26: Thank You
add_thankyou_slide(prs, "Thank You",
    "Questions?\n\nContact:\nRamanagouda S Patil\nUSN: 01FE23BCA207\nKLE Technological University\n\nGuided by: Prof. Anusha Hiremath")

# Save presentation
output_path = "customer_segmentation_presentation.pptx"
prs.save(output_path)
print(f"Presentation saved as: {output_path}")
print(f"Total slides: {len(prs.slides)}")
